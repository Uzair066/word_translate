"use strict";
(() => {
var exports = {};
exports.id = 552;
exports.ids = [552];
exports.modules = {

/***/ 376:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(924);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(201);
/* harmony import */ var _context_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(268);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(565);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_5__, react_hot_toast__WEBPACK_IMPORTED_MODULE_6__]);
([axios__WEBPACK_IMPORTED_MODULE_5__, react_hot_toast__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";










function WordTranslate({ englishData , wordApiData , wordToTranslate  }) {
    var ref, ref1, ref2, ref3;
    const { theme  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context_context__WEBPACK_IMPORTED_MODULE_7__/* .Message_data */ .L);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { 0: inputWord , 1: setInputWord  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]);
    const { 0: validated , 1: setValidated  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const handleSubmit = (e)=>{
        e.preventDefault();
        if (validateVendorForm()) {
            router.push(`${inputWord}-${(wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "urdu" ? "meaning-in-urdu" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "punjabi" ? "meaning-in-punjabi" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "hindi" ? "meaning-in-hindi" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "tamil" ? "meaning-in-tamil" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "telugu" ? "meaning-in-telugu" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "bengali" ? "meaning-in-bengali" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "kannada" ? "meaning-in-kannada" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "marathi" ? "meaning-in-marathi" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "malayalam" ? "meaning-in-malayalam" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "gujarati" ? "meaning-in-gujarati" : null}`);
        }
    };
    const validateVendorForm = ()=>{
        if (inputWord == "" || inputWord == null) {
            setValidated(false);
            return false;
        }
        setValidated(true);
        return true;
    };
    let count = 0;
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setInputWord(wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]);
        count++;
    }, [
        wordToTranslate,
        wordApiData
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
        maxWidth: "lg",
        sx: {
            paddingBottom: "90px"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    backgroundColor: theme === "dark" ? "#303030 !important" : "#fff !important",
                    padding: "30px 0 30px 0",
                    marginTop: "90px",
                    borderRadius: "4px 4px 4px 4px",
                    "& h1": {
                        fontSize: "1.5rem",
                        fontWeight: "600",
                        color: theme === "dark" ? "white" : "black",
                        fontFamily: '"Nunito", sans-serif',
                        margin: "unset",
                        paddingBottom: "10px"
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                    maxWidth: "sm",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            children: "Look up a word, learn it forever."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            onSubmit: handleSubmit,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                sx: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 1
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, {
                                        hiddenLabel: true,
                                        size: "small",
                                        value: inputWord,
                                        onChange: (e)=>setInputWord(e.target.value),
                                        sx: {
                                            width: "100%",
                                            background: "white",
                                            borderRadius: "5px",
                                            fontSize: "3rem"
                                        },
                                        type: "text",
                                        error: !validated && (inputWord == "" || inputWord == null),
                                        inputProps: {
                                            placeholder: "Enter a word"
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        variant: "contained",
                                        size: "large",
                                        type: "submit",
                                        sx: {
                                            height: "40px",
                                            background: "orange",
                                            "&:hover": {
                                                background: "orange"
                                            }
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4___default()), {})
                                    })
                                ]
                            })
                        }),
                        !validated && (inputWord == "" || inputWord == null) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                            sx: {
                                fontSize: "medium",
                                fontWeight: "bold",
                                color: "red",
                                paddingTop: "5px",
                                paddingLeft: "1rem"
                            },
                            children: "Word is required!"
                        }) : null
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    backgroundColor: theme === "dark" ? "#303030 !important" : "#fff",
                    padding: "30px 0 30px 0",
                    marginTop: "2rem",
                    borderRadius: "4px 4px 4px 4px"
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                    maxWidth: "lg",
                    children: [
                        loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: !!wordApiData.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        sx: {
                                            "& .wordTxt": {
                                                fontSize: "50px",
                                                color: "orange",
                                                fontWeight: "700",
                                                fontFamily: '"Nunito",sans-serif',
                                                textTransform: "capitalize",
                                                textAlign: "center"
                                            },
                                            "& span": {
                                                fontSize: "50px",
                                                color: theme === "dark" ? "#fff !important" : "#303030 !important",
                                                fontWeight: "500",
                                                fontFamily: '"Nunito",sans-serif',
                                                textTransform: "capitalize"
                                            }
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "wordTxt",
                                            children: [
                                                wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0],
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "Meaning in"
                                                }),
                                                " ",
                                                wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        sx: {
                                            "& .wordTxt": {
                                                fontSize: "20px",
                                                color: "orange",
                                                fontWeight: "500",
                                                fontFamily: '"Nunito",sans-serif',
                                                textTransform: "capitalize",
                                                textAlign: "center"
                                            }
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "wordTxt",
                                            children: [
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "kannada" && `ಇದರ ನಿಜವಾದ ಅರ್ಥವನ್ನು ತಿಳಿಯಿರಿ ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} ಸರಳ ಉದಾಹರಣೆಗಳು ಮತ್ತು ವ್ಯಾಖ್ಯಾನಗಳೊಂದಿಗೆ`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "hindi" && `जानें इसका सही मतलब ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} सरल उदाहरणों और परिभाषाओं के साथ`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "tamil" && `என்பதன் உண்மையான அர்த்தத்தை அறிக ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} எளிய எடுத்துக்காட்டுகள் மற்றும் வரையறைகளுடன்`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "telugu" && `యొక్క నిజమైన అర్థం తెలుసుకోండి ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} సాధారణ ఉదాహరణలు మరియు నిర్వచనాలతో`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "bengali" && `এর প্রকৃত অর্থ জানুন ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} সহজ উদাহরণ এবং সংজ্ঞা সহ`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "marathi" && `चा खरा अर्थ जाणून घ्या ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} साधी उदाहरणे आणि व्याख्या सह`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "malayalam" && `എന്നതിൻ്റെ യഥാർത്ഥ അർത്ഥം മനസ്സിലാക്കുക ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} ലളിതമായ ഉദാഹരണങ്ങളും നിർവചനങ്ങളും സഹിതം`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "gujrati" && `નો સાચો અર્થ જાણો ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} સરળ ઉદાહરણો અને વ્યાખ્યાઓ સાથે`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "punjabi" && `ਦਾ ਸਹੀ ਅਰਥ ਜਾਣੋ ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} ਸਧਾਰਨ ਉਦਾਹਰਣਾਂ ਅਤੇ ਪਰਿਭਾਸ਼ਾਵਾਂ ਦੇ ਨਾਲ`,
                                                (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "urdu" && `کے حقیقی معنی جانیں۔ ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} سادہ مثالوں اور تعریفوں کے ساتھ`
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        sx: {
                                            "& .wordTxt": {
                                                fontSize: "56px",
                                                color: "orange",
                                                fontWeight: "900",
                                                fontFamily: '"Nunito",sans-serif',
                                                textTransform: "capitalize"
                                            },
                                            "& span": {
                                                fontSize: "x-large",
                                                color: theme === "dark" ? "#fff !important" : "#303030 !important",
                                                fontWeight: "700",
                                                fontFamily: '"Nunito",sans-serif',
                                                textTransform: "capitalize"
                                            }
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "wordTxt",
                                                children: wordApiData === null || wordApiData === void 0 ? void 0 : (ref = wordApiData[0]) === null || ref === void 0 ? void 0 : ref.word_translated
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                        container: true,
                                        spacing: 4,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 9,
                                                children: !!wordApiData.length && (wordApiData === null || wordApiData === void 0 ? void 0 : wordApiData.map((item, index)=>{
                                                    var ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, ref10;
                                                    /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                        sx: {
                                                            marginTop: "20px",
                                                            backgroundColor: "#d1d1d1",
                                                            borderRadius: "22px",
                                                            padding: "34px 34px 34px 34px",
                                                            minHeight: "200px",
                                                            "& p": {
                                                                fontFamily: '"Nunito",sans-serif'
                                                            }
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                    children: `Definition of ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]}: `
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                                sx: {
                                                                    display: "flex",
                                                                    marginBottom: "8px",
                                                                    flexWrap: "wrap",
                                                                    flexDirection: "column",
                                                                    "& p": {
                                                                        marginBottom: "0px"
                                                                    }
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: item === null || item === void 0 ? void 0 : item.definition
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        style: {
                                                                            fontSize: "small",
                                                                            color: "#716f6f"
                                                                        },
                                                                        children: englishData === null || englishData === void 0 ? void 0 : (ref = englishData[index]) === null || ref === void 0 ? void 0 : ref.definition
                                                                    })
                                                                ]
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.synonyms) !== "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                    children: `Synonyms of ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]}: `
                                                                })
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.synonyms) === "" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                                sx: {
                                                                    width: "100%",
                                                                    display: "flex",
                                                                    alignItems: "center",
                                                                    gap: 1,
                                                                    flexWrap: "wrap",
                                                                    paddingBottom: "5px",
                                                                    "& .textToClick": {
                                                                        background: "white",
                                                                        padding: "0.5rem",
                                                                        borderRadius: "0.25rem",
                                                                        textTransform: "capitalize",
                                                                        cursor: "pointer",
                                                                        "&:hover": {
                                                                            backgroundColor: "rgba(180,180,180,1)"
                                                                        }
                                                                    }
                                                                },
                                                                children: item === null || item === void 0 ? void 0 : (ref1 = item.synonyms) === null || ref1 === void 0 ? void 0 : ref1.map((data, i)=>{
                                                                    var ref, ref1, ref2;
                                                                    /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                                        className: "textToClick",
                                                                        onClick: ()=>{
                                                                            var ref, ref1;
                                                                            return router.push(`/en/${englishData === null || englishData === void 0 ? void 0 : (ref = englishData[index]) === null || ref === void 0 ? void 0 : (ref1 = ref.synonyms) === null || ref1 === void 0 ? void 0 : ref1[i]}-meaning-in-${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]}`);
                                                                        },
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                children: data
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                style: {
                                                                                    fontSize: "small",
                                                                                    color: "#716f6f"
                                                                                },
                                                                                children: (englishData === null || englishData === void 0 ? void 0 : (ref = englishData[index]) === null || ref === void 0 ? void 0 : ref.synonyms) !== "" && (englishData === null || englishData === void 0 ? void 0 : (ref1 = englishData[index]) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.synonyms) === null || ref2 === void 0 ? void 0 : ref2[i])
                                                                            })
                                                                        ]
                                                                    }, i);
                                                                })
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.has_parts) !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                            children: "Has Parts: "
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                                        sx: {
                                                                            marginBottom: "8px"
                                                                        },
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                children: (item === null || item === void 0 ? void 0 : item.has_parts) === "" ? null : item === null || item === void 0 ? void 0 : (ref2 = item.has_parts) === null || ref2 === void 0 ? void 0 : ref2.toString()
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                style: {
                                                                                    fontSize: "small",
                                                                                    color: "#716f6f"
                                                                                },
                                                                                children: (englishData === null || englishData === void 0 ? void 0 : (ref3 = englishData[index]) === null || ref3 === void 0 ? void 0 : ref3.has_parts) === "" ? null : englishData === null || englishData === void 0 ? void 0 : (ref4 = englishData[index]) === null || ref4 === void 0 ? void 0 : (ref5 = ref4.has_parts) === null || ref5 === void 0 ? void 0 : ref5.toString()
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.is_a_type_of) !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                            children: `${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]} is a Type of: `
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                                        sx: {
                                                                            marginBottom: "8px"
                                                                        },
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                children: (item === null || item === void 0 ? void 0 : item.is_a_type_of) === "" ? null : item === null || item === void 0 ? void 0 : (ref6 = item.is_a_type_of) === null || ref6 === void 0 ? void 0 : ref6.toString()
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                                style: {
                                                                                    fontSize: "small",
                                                                                    color: "#716f6f"
                                                                                },
                                                                                children: (englishData === null || englishData === void 0 ? void 0 : (ref7 = englishData[index]) === null || ref7 === void 0 ? void 0 : ref7.is_a_type_of) === "" ? null : englishData === null || englishData === void 0 ? void 0 : (ref8 = englishData[index]) === null || ref8 === void 0 ? void 0 : (ref9 = ref8.is_a_type_of) === null || ref9 === void 0 ? void 0 : ref9.toString()
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.examples) !== "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                    children: `Examples of ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]}: `
                                                                })
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.examples) === "" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                                style: {
                                                                    paddingLeft: "2rem"
                                                                },
                                                                children: item === null || item === void 0 ? void 0 : (ref10 = item.examples) === null || ref10 === void 0 ? void 0 : ref10.map((data, i)=>{
                                                                    var ref, ref1, ref2;
                                                                    /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                style: {
                                                                                    width: "100%",
                                                                                    display: "block"
                                                                                },
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("q", {
                                                                                        style: {
                                                                                            fontSize: "16px",
                                                                                            fontFamily: '"Nunito",sans-serif'
                                                                                        },
                                                                                        children: data
                                                                                    })
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("q", {
                                                                                        style: {
                                                                                            fontSize: "small",
                                                                                            color: "#716f6f",
                                                                                            fontFamily: '"Nunito",sans-serif'
                                                                                        },
                                                                                        children: (englishData === null || englishData === void 0 ? void 0 : (ref = englishData[index]) === null || ref === void 0 ? void 0 : ref.examples) !== "" && (englishData === null || englishData === void 0 ? void 0 : (ref1 = englishData[index]) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.examples) === null || ref2 === void 0 ? void 0 : ref2[i])
                                                                                    })
                                                                                })
                                                                            })
                                                                        ]
                                                                    }, i);
                                                                })
                                                            })
                                                        ]
                                                    }, index);
                                                }))
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 3,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                    sx: {
                                                        position: "relative",
                                                        marginTop: "20px",
                                                        backgroundColor: "#d1d1d1",
                                                        borderRadius: "22px",
                                                        padding: "10px 30px 30px 30px",
                                                        minHeight: "200px"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                            sx: {
                                                                textAlign: "center",
                                                                paddingBottom: "10px",
                                                                "& .wordTxt": {
                                                                    fontSize: "40px",
                                                                    fontWeight: "900",
                                                                    fontFamily: '"Nunito",sans-serif',
                                                                    textTransform: "capitalize",
                                                                    color: "orange"
                                                                }
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "wordTxt",
                                                                children: "Rhymes"
                                                            })
                                                        }),
                                                        !!wordApiData.length && (wordApiData === null || wordApiData === void 0 ? void 0 : (ref1 = wordApiData[0]) === null || ref1 === void 0 ? void 0 : ref1.rhymes) === "" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                            sx: {
                                                                "& .theWord": {
                                                                    fontWeight: 500,
                                                                    fontFamily: '"Nunito",sans-serif',
                                                                    width: "100%",
                                                                    fontSize: "16px",
                                                                    padding: "5px 7px 5px 11px",
                                                                    marginBottom: "10px",
                                                                    transition: ".3s ease",
                                                                    borderRadius: "75px",
                                                                    backgroundColor: "rgba(255,255,255,1)",
                                                                    color: "black",
                                                                    display: "flex",
                                                                    alignItems: "center",
                                                                    cursor: "pointer",
                                                                    "&:hover": {
                                                                        backgroundColor: "rgba(180,180,180,1)"
                                                                    }
                                                                }
                                                            },
                                                            children: (ref2 = wordApiData[0]) === null || ref2 === void 0 ? void 0 : (ref3 = ref2.rhymes) === null || ref3 === void 0 ? void 0 : ref3.map((data, index)=>{
                                                                var ref, ref1, ref2;
                                                                /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                    className: "theWord",
                                                                    onClick: ()=>{
                                                                        var ref, ref1;
                                                                        return router.push(`/en/${englishData === null || englishData === void 0 ? void 0 : (ref = englishData[0]) === null || ref === void 0 ? void 0 : (ref1 = ref.rhymes) === null || ref1 === void 0 ? void 0 : ref1[index]}-meaning-in-${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]}`);
                                                                    },
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                            sx: {
                                                                                fontSize: "16px",
                                                                                marginRight: "10px"
                                                                            }
                                                                        }),
                                                                        data,
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                        (englishData === null || englishData === void 0 ? void 0 : (ref = englishData[0]) === null || ref === void 0 ? void 0 : ref.rhymes) !== "" && (englishData === null || englishData === void 0 ? void 0 : (ref1 = englishData[0]) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.rhymes) === null || ref2 === void 0 ? void 0 : ref2[index])
                                                                    ]
                                                                }, index);
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                sx: {
                                    fontSize: "2rem",
                                    fontWeight: "bold",
                                    color: "red",
                                    textAlign: "center",
                                    fontFamily: '"Nunito",sans-serif'
                                },
                                children: `No word details found for ${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]}!`
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.Toaster, {
                toastOptions: {
                    style: {
                        fontFamily: '"Nunito",sans-serif'
                    }
                },
                position: "top-right"
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WordTranslate);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 797:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_en_WordTranslate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(924);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_en_WordTranslate__WEBPACK_IMPORTED_MODULE_1__, axios__WEBPACK_IMPORTED_MODULE_2__]);
([_components_en_WordTranslate__WEBPACK_IMPORTED_MODULE_1__, axios__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




function DetailPageTranslation({ engData , wordData , wordToTranslate  }) {
    console.log(wordData);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Create Next App"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_en_WordTranslate__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    wordToTranslate: wordToTranslate,
                    englishData: engData,
                    wordApiData: wordData
                })
            })
        ]
    });
}
async function getServerSideProps({ query  }) {
    const { wordToTranslate  } = query;
    const resSearch = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`https://api.browseword.com/api/search?word=${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]}`);
    let englishData = (resSearch === null || resSearch === void 0 ? void 0 : resSearch.data) || null;
    const resDetails = await axios__WEBPACK_IMPORTED_MODULE_2__["default"].get(`https://api.browseword.com/api/en/${(wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "urdu" ? "english-to-urdu" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "punjabi" ? "english-to-punjabi" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "hindi" ? "english-to-hindi" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "tamil" ? "english-to-tamil" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "telugu" ? "english-to-telugu" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "bengali" ? "english-to-bengali" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "kannada" ? "english-to-kannada" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "marathi" ? "english-to-marathi" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "malayalam" ? "english-to-malayalam" : (wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[1]) === "gujarati" ? "english-to-gujarati" : null}?word=${wordToTranslate === null || wordToTranslate === void 0 ? void 0 : wordToTranslate.split("-meaning-in-")[0]}`);
    let wordApiData = (resDetails === null || resDetails === void 0 ? void 0 : resDetails.data) || null;
    return {
        props: {
            wordToTranslate: wordToTranslate,
            engData: englishData,
            wordData: wordApiData
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailPageTranslation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 17:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 48:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [268,565], () => (__webpack_exec__(797)));
module.exports = __webpack_exports__;

})();