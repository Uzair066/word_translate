"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 935:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
;// CONCATENATED MODULE: external "@mui/icons-material/Twitter"
const Twitter_namespaceObject = require("@mui/icons-material/Twitter");
var Twitter_default = /*#__PURE__*/__webpack_require__.n(Twitter_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/FacebookOutlined"
const FacebookOutlined_namespaceObject = require("@mui/icons-material/FacebookOutlined");
var FacebookOutlined_default = /*#__PURE__*/__webpack_require__.n(FacebookOutlined_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Instagram"
const Instagram_namespaceObject = require("@mui/icons-material/Instagram");
var Instagram_default = /*#__PURE__*/__webpack_require__.n(Instagram_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/LinkedIn"
const LinkedIn_namespaceObject = require("@mui/icons-material/LinkedIn");
var LinkedIn_default = /*#__PURE__*/__webpack_require__.n(LinkedIn_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/KeyboardArrowRight"
const KeyboardArrowRight_namespaceObject = require("@mui/icons-material/KeyboardArrowRight");
// EXTERNAL MODULE: ./context/context.js
var context = __webpack_require__(268);
;// CONCATENATED MODULE: ./components/Footer/Footer.jsx










function Footer() {
    const { theme  } = (0,external_react_.useContext)(context/* Message_data */.L);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
            sx: {
                display: "flex",
                backgroundColor: "#333",
                flexWrap: "wrap",
                gap: 5,
                borderTop: "1px solid #333",
                padding: "30px 0px 30px 0px",
                justifyContent: "space-around"
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    sx: {
                        display: "flex",
                        // alignItems: "center",
                        gap: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Twitter_default()), {
                            sx: {
                                color: "white",
                                cursor: "pointer"
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((FacebookOutlined_default()), {
                            sx: {
                                color: "white",
                                cursor: "pointer"
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Instagram_default()), {
                            sx: {
                                color: "white",
                                cursor: "pointer"
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((LinkedIn_default()), {
                            sx: {
                                color: "white",
                                cursor: "pointer"
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                    sx: {
                        display: "flex",
                        gap: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                display: "flex",
                                "& span": {
                                    color: "white",
                                    transition: "0.3s",
                                    fontFamily: '"Open Sans", sans-serif',
                                    fontSize: "14px",
                                    cursor: "pointer",
                                    "&:hover": {
                                        color: "orange"
                                    }
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                style: {
                                    borderBottom: "1px solid orange "
                                },
                                children: "About us"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                display: "flex",
                                "& span": {
                                    color: "white",
                                    transition: "0.3s",
                                    fontFamily: '"Open Sans", sans-serif',
                                    fontSize: "14px",
                                    cursor: "pointer",
                                    "&:hover": {
                                        color: "orange"
                                    }
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                style: {
                                    borderBottom: "1px solid orange "
                                },
                                children: "Privacy policy"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                display: "flex",
                                "& span": {
                                    color: "white",
                                    transition: "0.3s",
                                    fontFamily: '"Open Sans", sans-serif',
                                    fontSize: "14px",
                                    cursor: "pointer",
                                    "&:hover": {
                                        color: "orange"
                                    }
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                style: {
                                    borderBottom: "1px solid orange "
                                },
                                children: "Terms of service"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        "& .copyright": {
                            textAlign: "center",
                            color: "white",
                            fontFamily: '"Nunito", sans-serif',
                            fontSize: "14px"
                        }
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "copyright",
                        children: [
                            "\xa9 Copyright",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("strong", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "LOGO"
                                })
                            }),
                            ". All Rights Reserved"
                        ]
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const Footer_Footer = (Footer);

;// CONCATENATED MODULE: external "@mui/material/AppBar"
const AppBar_namespaceObject = require("@mui/material/AppBar");
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_namespaceObject);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
;// CONCATENATED MODULE: external "@mui/material/Toolbar"
const Toolbar_namespaceObject = require("@mui/material/Toolbar");
var Toolbar_default = /*#__PURE__*/__webpack_require__.n(Toolbar_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/IconButton"
const IconButton_namespaceObject = require("@mui/material/IconButton");
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Typography"
const Typography_namespaceObject = require("@mui/material/Typography");
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Menu"
const Menu_namespaceObject = require("@mui/material/Menu");
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Menu"
const icons_material_Menu_namespaceObject = require("@mui/icons-material/Menu");
var icons_material_Menu_default = /*#__PURE__*/__webpack_require__.n(icons_material_Menu_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Container"
const Container_namespaceObject = require("@mui/material/Container");
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Button"
const Button_namespaceObject = require("@mui/material/Button");
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/MenuItem"
const MenuItem_namespaceObject = require("@mui/material/MenuItem");
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/Adb"
const Adb_namespaceObject = require("@mui/icons-material/Adb");
var Adb_default = /*#__PURE__*/__webpack_require__.n(Adb_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/WbSunny"
const WbSunny_namespaceObject = require("@mui/icons-material/WbSunny");
var WbSunny_default = /*#__PURE__*/__webpack_require__.n(WbSunny_namespaceObject);
;// CONCATENATED MODULE: external "@mui/icons-material/DarkMode"
const DarkMode_namespaceObject = require("@mui/icons-material/DarkMode");
var DarkMode_default = /*#__PURE__*/__webpack_require__.n(DarkMode_namespaceObject);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
;// CONCATENATED MODULE: ./components/Header/index.jsx
















const pages = [
    "Home",
    "About Us",
    "Blog"
];



const HeaderMain = ({ setMode  })=>{
    const router = (0,router_.useRouter)();
    const { theme , setTheme , setIsPageLoaded  } = (0,external_react_.useContext)(context/* Message_data */.L);
    const [anchorElNav, setAnchorElNav] = external_react_default().useState(null);
    const handleOpenNavMenu = (event)=>{
        setAnchorElNav(event.currentTarget);
    };
    const handleCloseNavMenu = ()=>{
        setAnchorElNav(null);
    };
    (0,external_react_.useEffect)(()=>{
        setMode(theme);
    }, [
        theme
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
        sx: {
            "& .MuiAppBar-colorPrimary": {
                background: "#333",
                position: "fixed",
                transition: "0.5s"
            }
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((AppBar_default()), {
            sx: {
                boxShadow: "none"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                maxWidth: "lg",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Toolbar_default()), {
                    disableGutters: true,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Adb_default()), {
                            sx: {
                                fill: "black",
                                display: {
                                    xs: "none",
                                    md: "flex"
                                },
                                mr: 1
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h6",
                            noWrap: true,
                            component: "a",
                            href: "/",
                            sx: {
                                mr: 2,
                                display: {
                                    xs: "none",
                                    md: "flex"
                                },
                                textDecoration: "none",
                                fontSize: "30px",
                                fontWeight: "700",
                                letterSpacing: "1px",
                                color: "white",
                                fontFamily: '"Nunito", sans-serif'
                            },
                            children: "LOGO"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                            sx: {
                                flexGrow: 1,
                                display: {
                                    xs: "flex",
                                    md: "none"
                                }
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    size: "large",
                                    "aria-label": "account of current user",
                                    "aria-controls": "menu-appbar",
                                    "aria-haspopup": "true",
                                    onClick: handleOpenNavMenu,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((icons_material_Menu_default()), {})
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Menu_default()), {
                                    id: "menu-appbar",
                                    anchorEl: anchorElNav,
                                    anchorOrigin: {
                                        vertical: "bottom",
                                        horizontal: "left"
                                    },
                                    keepMounted: true,
                                    transformOrigin: {
                                        vertical: "top",
                                        horizontal: "left"
                                    },
                                    open: Boolean(anchorElNav),
                                    onClose: handleCloseNavMenu,
                                    sx: {
                                        display: {
                                            xs: "block",
                                            md: "none"
                                        }
                                    },
                                    PaperProps: {
                                        style: {
                                            width: "100%"
                                        }
                                    },
                                    children: [
                                        pages.map((page)=>/*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                                                onClick: ()=>{
                                                    handleCloseNavMenu();
                                                    router.push("/");
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    textAlign: "center",
                                                    children: page
                                                })
                                            }, page)),
                                        /*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                                            onClick: ()=>{
                                                handleCloseNavMenu();
                                                setIsPageLoaded(false);
                                                setTimeout(()=>{
                                                    router.push("/top200");
                                                }, 1000);
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                textAlign: "center",
                                                children: "Top 200"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Adb_default()), {
                            sx: {
                                display: {
                                    xs: "flex",
                                    md: "none"
                                },
                                mr: 1
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h5",
                            noWrap: true,
                            component: "a",
                            href: "",
                            sx: {
                                mr: 2,
                                display: {
                                    xs: "flex",
                                    md: "none"
                                },
                                flexGrow: 1,
                                textDecoration: "none",
                                fontSize: "30px",
                                fontWeight: "700",
                                letterSpacing: "1px",
                                color: "white",
                                fontFamily: '"Nunito", sans-serif'
                            },
                            children: "LOGO"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                            sx: {
                                flexGrow: 1,
                                display: {
                                    xs: "none",
                                    md: "flex"
                                },
                                justifyContent: "center",
                                gap: 3
                            },
                            children: [
                                pages.map((page)=>/*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        onClick: ()=>{
                                            handleCloseNavMenu();
                                            if (page === "Home") router.push("/");
                                        },
                                        sx: {
                                            // my: 2,
                                            display: "block",
                                            fontSize: "16px",
                                            fontWeight: "700",
                                            color: "white",
                                            whiteSpace: "nowrap",
                                            transition: "0.3s",
                                            textTransform: "none",
                                            fontFamily: '"Nunito", sans-serif',
                                            "&:hover": {
                                                color: "white"
                                            }
                                        },
                                        children: page
                                    }, page)),
                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    onClick: ()=>{
                                        handleCloseNavMenu();
                                        setIsPageLoaded(false);
                                        setTimeout(()=>{
                                            router.push("/top200");
                                        }, 1000);
                                    },
                                    sx: {
                                        // my: 2,
                                        display: "block",
                                        fontSize: "16px",
                                        fontWeight: "700",
                                        color: "orange",
                                        whiteSpace: "nowrap",
                                        transition: "0.3s",
                                        textTransform: "none",
                                        fontFamily: '"Nunito", sans-serif',
                                        "&:hover": {
                                            color: "orange"
                                        }
                                    },
                                    children: "Top 200"
                                })
                            ]
                        }),
                        theme === "light" ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Tooltip, {
                            title: "Dark Mode",
                            placement: "left",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((DarkMode_default()), {
                                sx: {
                                    cursor: "pointer"
                                },
                                onClick: ()=>setTheme("dark")
                            })
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Tooltip, {
                            title: "Light Mode",
                            placement: "left",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((WbSunny_default()), {
                                sx: {
                                    cursor: "pointer"
                                },
                                onClick: ()=>setTheme("light")
                            })
                        })
                    ]
                })
            })
        })
    });
};

;// CONCATENATED MODULE: external "@mui/material/styles"
const styles_namespaceObject = require("@mui/material/styles");
;// CONCATENATED MODULE: external "@mui/material/CssBaseline"
const CssBaseline_namespaceObject = require("@mui/material/CssBaseline");
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_namespaceObject);
// EXTERNAL MODULE: ./components/Loader.jsx
var Loader = __webpack_require__(565);
;// CONCATENATED MODULE: ./components/main.jsx
"use client";









function Main({ Component , pageProps  }) {
    const { asPath  } = (0,router_.useRouter)();
    const { 0: loaderFade , 1: setLoaderFade  } = (0,external_react_.useState)(false);
    const { 0: mode , 1: setMode  } = (0,external_react_.useState)("light");
    const { isPageLoaded , setIsPageLoaded  } = (0,external_react_.useContext)(context/* Message_data */.L);
    const { 0: firstPageLoad , 1: setFirstPageLoad  } = (0,external_react_.useState)(true);
    const { 0: circleShow , 1: setCircleShow  } = (0,external_react_.useState)(false);
    const muiTheme = (0,styles_namespaceObject.createTheme)({
        components: {
            MuiCssBaseline: {
                styleOverrides: {
                    body: {
                        backgroundColor: mode === "dark" ? "black" : "#ccc"
                    }
                }
            }
        }
    });
    (0,external_react_.useEffect)(()=>{
        const handleLoad = ()=>{
            setCircleShow(true);
            setTimeout(()=>{
                setFirstPageLoad(false);
                setLoaderFade(true);
            }, 500);
            setTimeout(()=>{
                setIsPageLoaded(true);
                setLoaderFade(false);
            }, 1000);
        };
        if (document.readyState === "interactive" || document.readyState === "complete") {
            handleLoad();
        } else {
            window.addEventListener("load", ()=>{
                setIsPageLoaded(false);
            });
        }
        return ()=>{
            window.removeEventListener("load", ()=>{
                setIsPageLoaded(false);
            });
        };
    }, [
        asPath
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            !isPageLoaded && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    firstPageLoad && /*#__PURE__*/ jsx_runtime_.jsx(Loader/* default */.Z, {
                        classes: "loaderBackground"
                    }),
                    loaderFade && /*#__PURE__*/ jsx_runtime_.jsx(Loader/* default */.Z, {
                        circleShow: circleShow,
                        classes: "loaderBarUnload"
                    }),
                    !loaderFade && /*#__PURE__*/ jsx_runtime_.jsx(Loader/* default */.Z, {
                        classes: "loaderBar"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(styles_namespaceObject.ThemeProvider, {
                theme: muiTheme,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CssBaseline_default()), {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HeaderMain, {
                        setMode: setMode,
                        setIsPageLoaded: setIsPageLoaded
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {
                        setIsPageLoaded: setIsPageLoaded
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./pages/_app.js




function App({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(context/* default */.Z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Main, {
            Component: Component,
            pageProps: pageProps
        })
    });
}


/***/ }),

/***/ 692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 48:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [268,565], () => (__webpack_exec__(935)));
module.exports = __webpack_exports__;

})();