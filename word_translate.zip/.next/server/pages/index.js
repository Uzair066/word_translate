"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 888:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_Home),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(17);
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(853);
// EXTERNAL MODULE: ./context/context.js
var context = __webpack_require__(268);
;// CONCATENATED MODULE: ./components/Home/popularWords.jsx






function PopularWords({ popular  }) {
    const { setIsPageLoaded  } = (0,external_react_.useContext)(context/* Message_data */.L);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            marginTop: "63px",
            position: "relative",
            backgroundColor: "#d1d1d1",
            borderRadius: "22px",
            padding: "37px 34px 34px 34px",
            minHeight: "349px"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    position: "absolute",
                    width: "300px",
                    top: "-55px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    "& .wordTxt": {
                        fontSize: "56px",
                        left: "0",
                        top: "0",
                        color: "orange",
                        position: "absolute",
                        fontWeight: "900",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .ofTxt": {
                        fontSize: "22px",
                        left: "-3px",
                        top: "60px",
                        position: "absolute",
                        color: "#ffffff",
                        fontWeight: "700",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .theTxt": {
                        fontSize: "41px",
                        left: "85px",
                        top: "35px",
                        position: "absolute",
                        color: "#021f39",
                        fontFamily: "'MondayFont', cursive",
                        whiteSpace: "nowrap",
                        fontWeight: "600"
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "wordTxt",
                        children: "POPULAR"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "theTxt",
                        children: "words"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                container: true,
                spacing: 2,
                sx: {
                    marginTop: "0.5rem"
                },
                children: !!popular.length && popular.map((item, index)=>{
                    /*#__PURE__*/ return jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 3,
                        xl: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: `/en/${item === null || item === void 0 ? void 0 : item.word}-meaning-in-hindi`,
                            onClick: ()=>setIsPageLoaded(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                sx: {
                                    borderRadius: "0.25rem",
                                    cursor: "pointer",
                                    display: "flex",
                                    alignItems: "center",
                                    backgroundColor: "white",
                                    padding: "0.5rem",
                                    "&:hover": {
                                        backgroundColor: "rgba(180,180,180,1)"
                                    },
                                    "& p": {
                                        textTransform: "capitalize",
                                        fontSize: ".875rem",
                                        lineHeight: "1.25rem",
                                        margin: "0px",
                                        fontFamily: '"Nunito", sans-serif'
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Search_default()), {
                                        sx: {
                                            fontSize: "16px",
                                            marginRight: "10px"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: item === null || item === void 0 ? void 0 : item.word
                                    })
                                ]
                            })
                        })
                    }, index);
                })
            })
        ]
    });
}
/* harmony default export */ const popularWords = (PopularWords);

;// CONCATENATED MODULE: ./components/Home/languageDictionaries.jsx






function LanguageDictionaries() {
    const { setSelectedLanguage  } = (0,external_react_.useContext)(context/* Message_data */.L);
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            marginTop: "63px",
            position: "relative",
            backgroundColor: "#d1d1d1",
            borderRadius: "22px",
            padding: "37px 34px 34px 34px",
            minHeight: "349px"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    position: "absolute",
                    width: "350px",
                    top: "-55px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    "& .wordTxt": {
                        fontSize: "56px",
                        left: "0",
                        top: "0",
                        color: "orange",
                        position: "absolute",
                        fontWeight: "900",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .ofTxt": {
                        fontSize: "22px",
                        left: "-3px",
                        top: "60px",
                        position: "absolute",
                        color: "#ffffff",
                        fontWeight: "700",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .theTxt": {
                        fontSize: "41px",
                        left: "60px",
                        top: "35px",
                        position: "absolute",
                        color: "#021f39",
                        fontFamily: "'MondayFont', cursive",
                        whiteSpace: "nowrap",
                        fontWeight: "600"
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "wordTxt",
                        children: "LANGUAGE"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "theTxt",
                        children: "Dictionaries"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                spacing: 3,
                sx: {
                    marginTop: "0.5rem"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-hindi");
                                router.push(`en/dictionary/english-to-hindi/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Hindi"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-tamil");
                                router.push(`en/dictionary/english-to-tamil/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Tamil"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-telugu");
                                router.push(`en/dictionary/english-to-telugu/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Telugu"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-bengali");
                                router.push(`en/dictionary/english-to-bengali/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Bengali"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-kannada");
                                router.push(`en/dictionary/english-to-kannada/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Kannada"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-marathi");
                                router.push(`en/dictionary/english-to-marathi/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Marathi"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-malayalam");
                                router.push(`en/dictionary/english-to-malayalam/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Malayalam"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-gujarati");
                                router.push(`en/dictionary/english-to-gujarati/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Gujarati"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-punjabi");
                                router.push(`en/dictionary/english-to-punjabi/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Punjabi"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                            sx: {
                                borderRadius: "0.75rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                backgroundColor: "white",
                                padding: "1rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                setSelectedLanguage("english-to-urdu");
                                router.push(`en/dictionary/english-to-urdu/1`);
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "English to Urdu"
                            })
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const languageDictionaries = (LanguageDictionaries);

// EXTERNAL MODULE: ./components/Home/alphabets.jsx
var alphabets = __webpack_require__(965);
;// CONCATENATED MODULE: ./components/Home/index.js
"use client";










function Home({ posts  }) {
    const router = (0,router_.useRouter)();
    const { theme , isPageLoaded , setIsPageLoaded  } = (0,external_react_.useContext)(context/* Message_data */.L);
    // const [popular, setPopular] = useState([posts]);
    const { 0: inputWord , 1: setInputWord  } = (0,external_react_.useState)("");
    const { 0: validated , 1: setValidated  } = (0,external_react_.useState)(true);
    const handleSubmit = (e)=>{
        e.preventDefault();
        if (validateVendorForm()) {
            setIsPageLoaded(false);
            setTimeout(()=>{
                router.push(`dictionary/${inputWord}`);
            }, 1000);
        }
    };
    const validateVendorForm = ()=>{
        if (inputWord == "" || inputWord == null) {
            setValidated(false);
            return false;
        }
        setValidated(true);
        return true;
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        backgroundColor: theme === "dark" ? "#303030 !important" : "#fff !important",
                        padding: "30px 0 30px 0",
                        marginTop: "90px",
                        borderRadius: "4px 4px 4px 4px"
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        container: true,
                        spacing: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                            item: true,
                            xs: 12,
                            md: 12,
                            sx: {
                                "& h1": {
                                    fontSize: "1.5rem",
                                    fontWeight: "600",
                                    color: theme === "dark" ? "white" : "black",
                                    fontFamily: '"Nunito", sans-serif',
                                    margin: "unset",
                                    paddingBottom: "10px"
                                }
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
                                maxWidth: "sm",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        children: "Look up a word, learn it forever."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("form", {
                                        onSubmit: handleSubmit,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                            sx: {
                                                display: "flex",
                                                alignItems: "center",
                                                gap: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.TextField, {
                                                    hiddenLabel: true,
                                                    size: "small",
                                                    value: inputWord,
                                                    onChange: (e)=>setInputWord(e.target.value),
                                                    sx: {
                                                        width: "100%",
                                                        background: "white",
                                                        borderRadius: "5px",
                                                        fontSize: "3rem"
                                                    },
                                                    type: "text",
                                                    error: !validated && (inputWord == "" || inputWord == null),
                                                    inputProps: {
                                                        placeholder: "Enter a word"
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                                    variant: "contained",
                                                    size: "medium",
                                                    type: "submit",
                                                    sx: {
                                                        height: "40px",
                                                        background: "orange",
                                                        "&:hover": {
                                                            background: "orange"
                                                        }
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Search_default()), {})
                                                })
                                            ]
                                        })
                                    }),
                                    !validated && (inputWord == "" || inputWord == null) ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                        sx: {
                                            fontSize: "medium",
                                            fontWeight: "bold",
                                            color: "red",
                                            paddingTop: "5px",
                                            paddingLeft: "1rem"
                                        },
                                        children: "Word is required!"
                                    }) : null
                                ]
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        backgroundColor: theme === "dark" ? "#303030 !important" : "white",
                        padding: "30px 83px 30px 83px",
                        marginTop: "1.6rem",
                        borderRadius: "4px 4px 4px 4px",
                        marginBottom: "90px",
                        paddingBottom: "5rem",
                        "@media only screen and (max-width:1024px)": {
                            padding: "30px 15px 30px 15px"
                        }
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        container: true,
                        spacing: 4,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                item: true,
                                xs: 12,
                                md: 6,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                    sx: {
                                        marginTop: "63px",
                                        position: "relative",
                                        backgroundColor: "#d1d1d1",
                                        borderRadius: "22px",
                                        padding: "37px 34px 34px 34px",
                                        minHeight: "349px",
                                        "& .theWord": {
                                            fontSize: "36px",
                                            color: "#262626",
                                            fontWeight: 500,
                                            fontFamily: '"Nunito",sans-serif',
                                            cursor: "pointer",
                                            paddingBottom: "1rem",
                                            "&:hover": {
                                                textDecoration: "underline"
                                            }
                                        },
                                        "& .synonymTxt": {
                                            fontSize: "22px",
                                            fontFamily: '"Nunito",sans-serif',
                                            marginBottom: "2rem"
                                        },
                                        "& .descriptionTxt": {
                                            fontSize: "18px",
                                            color: "#262626",
                                            fontFamily: '"Nunito",sans-serif',
                                            fontWeight: 400,
                                            fontStyle: "italic"
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                            sx: {
                                                position: "absolute",
                                                width: "165px",
                                                top: "-55px",
                                                left: "47%",
                                                transform: "translateX(-50%)",
                                                "& .wordTxt": {
                                                    fontSize: "56px",
                                                    left: "0",
                                                    top: "0",
                                                    color: "orange",
                                                    position: "absolute",
                                                    fontWeight: "900",
                                                    fontFamily: '"Nunito",sans-serif'
                                                },
                                                "& .ofTxt": {
                                                    fontSize: "22px",
                                                    left: "-3px",
                                                    top: "60px",
                                                    position: "absolute",
                                                    color: "#ffffff",
                                                    fontWeight: "700",
                                                    fontFamily: '"Nunito",sans-serif'
                                                },
                                                "& .theTxt": {
                                                    fontSize: "41px",
                                                    left: "28px",
                                                    top: "35px",
                                                    position: "absolute",
                                                    color: "#021f39",
                                                    fontFamily: "'MondayFont', cursive",
                                                    whiteSpace: "nowrap",
                                                    fontWeight: "600"
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "wordTxt",
                                                    children: "WORD"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "ofTxt",
                                                    children: "OF"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "theTxt",
                                                    children: [
                                                        "the",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: " "
                                                        }),
                                                        "day"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            onClick: ()=>router.push(`dictionary/sulk`),
                                            className: "theWord",
                                            children: "sulk"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "synonymTxt",
                                            children: "somurtmak"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "descriptionTxt",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("q", {
                                                children: "The little boy sulked in a corner after being scolded."
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "descriptionTxt",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("q", {
                                                children: "Azar işiten k\xfc\xe7\xfck \xe7ocuk, gidip bir k\xf6şede somurttu."
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                item: true,
                                xs: 12,
                                md: 6,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                    sx: {
                                        marginTop: "63px",
                                        position: "relative",
                                        backgroundColor: "#d1d1d1",
                                        borderRadius: "22px",
                                        padding: "40px 34px 34px 34px",
                                        minHeight: "349px",
                                        "& .theWord": {
                                            fontWeight: 500,
                                            fontFamily: '"Nunito",sans-serif',
                                            width: "100%",
                                            fontSize: "16px",
                                            padding: "5px 7px 5px 11px",
                                            margin: "3px",
                                            marginBottom: "10px",
                                            transition: ".3s ease",
                                            cursor: "pointer",
                                            borderRadius: "75px",
                                            backgroundColor: "rgba(255,255,255,1)",
                                            color: "black",
                                            display: "flex",
                                            alignItems: "center",
                                            "&:hover": {
                                                backgroundColor: "rgba(180,180,180,1)"
                                            }
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                            sx: {
                                                position: "absolute",
                                                width: "252px",
                                                top: "-55px",
                                                left: "43%",
                                                transform: "translateX(-50%)",
                                                "& .wordTxt": {
                                                    fontSize: "56px",
                                                    left: "0",
                                                    top: "0",
                                                    color: "orange",
                                                    position: "absolute",
                                                    fontWeight: "900",
                                                    fontFamily: '"Nunito",sans-serif'
                                                },
                                                "& .theTxt": {
                                                    fontSize: "41px",
                                                    left: "100px",
                                                    top: "35px",
                                                    position: "absolute",
                                                    color: "#021f39",
                                                    fontFamily: "'MondayFont', cursive",
                                                    whiteSpace: "nowrap",
                                                    fontWeight: "600"
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "wordTxt",
                                                    children: "TRENDING"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "theTxt",
                                                    children: "now"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            onClick: ()=>router.push(`dictionary/sulk`),
                                            className: "theWord",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Search_default()), {
                                                    sx: {
                                                        fontSize: "16px",
                                                        marginRight: "10px"
                                                    }
                                                }),
                                                "sulk"
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                item: true,
                                xs: 12,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(languageDictionaries, {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                item: true,
                                xs: 12,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(popularWords, {
                                    popular: posts
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                item: true,
                                xs: 12,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(alphabets/* default */.Z, {})
                            })
                        ]
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const components_Home = (Home);

;// CONCATENATED MODULE: ./pages/index.js



function pages_Home({ posts  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Create Next App"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(components_Home, {
                    posts: posts
                })
            })
        ]
    });
}
const getServerSideProps = async ()=>{
    const res = await fetch("https://api.browseword.com/api/top30words?limit=28");
    const posts = await res.json();
    return {
        props: {
            posts: posts || []
        }
    };
};


/***/ }),

/***/ 17:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [268,965], () => (__webpack_exec__(888)));
module.exports = __webpack_exports__;

})();