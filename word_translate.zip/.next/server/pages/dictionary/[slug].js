"use strict";
(() => {
var exports = {};
exports.id = 614;
exports.ids = [614];
exports.modules = {

/***/ 85:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(17);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(924);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(201);
/* harmony import */ var _context_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(268);
/* harmony import */ var _Loader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(565);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_5__, react_hot_toast__WEBPACK_IMPORTED_MODULE_6__]);
([axios__WEBPACK_IMPORTED_MODULE_5__, react_hot_toast__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";










function DictionarySlug({ wordApiData , slug  }) {
    var ref, ref1, ref2;
    const { theme , setIsPageLoaded  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context_context__WEBPACK_IMPORTED_MODULE_7__/* .Message_data */ .L);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    console.log(wordApiData);
    // const { slug } = router.query;
    // const [wordApiData, setWordApiData] = useState([]);
    const { 0: inputWord , 1: setInputWord  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(slug);
    const { 0: validated , 1: setValidated  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const handleSubmit = (e)=>{
        e.preventDefault();
        if (validateVendorForm()) {
            if (slug.toLowerCase() != inputWord.toLowerCase()) {
                setIsPageLoaded(false);
                setTimeout(()=>{
                    router.push(`${inputWord}`);
                }, 1000);
            }
        }
    };
    const validateVendorForm = ()=>{
        if (inputWord == "" || inputWord == null) {
            setValidated(false);
            return false;
        }
        setValidated(true);
        return true;
    };
    // let count = 0;
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        // setLoading(true)
        if (wordApiData === null) {
            setLoading(true);
        } else {
            setInputWord(slug);
            // setWordApiData(wordApiData);
            setLoading(false);
        }
    }, [
        slug,
        wordApiData
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
        maxWidth: "lg",
        sx: {
            paddingBottom: "90px"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    backgroundColor: theme === "dark" ? "#303030 !important" : "#fff !important",
                    padding: "30px 0 30px 0",
                    marginTop: "90px",
                    borderRadius: "4px 4px 4px 4px",
                    "& h1": {
                        fontSize: "1.5rem",
                        fontWeight: "600",
                        color: theme === "dark" ? "white" : "black",
                        fontFamily: '"Nunito", sans-serif',
                        margin: "unset",
                        paddingBottom: "10px"
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                    maxWidth: "sm",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            children: "Look up a word, learn it forever."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            onSubmit: handleSubmit,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                sx: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 1
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.TextField, {
                                        hiddenLabel: true,
                                        size: "small",
                                        value: inputWord,
                                        onChange: (e)=>setInputWord(e.target.value),
                                        sx: {
                                            width: "100%",
                                            background: "white",
                                            borderRadius: "5px",
                                            fontSize: "3rem"
                                        },
                                        type: "text",
                                        error: !validated && (inputWord == "" || inputWord == null),
                                        inputProps: {
                                            placeholder: "Enter a word"
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        variant: "contained",
                                        size: "large",
                                        type: "submit",
                                        sx: {
                                            height: "40px",
                                            background: "orange",
                                            "&:hover": {
                                                background: "orange"
                                            }
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4___default()), {})
                                    })
                                ]
                            })
                        }),
                        !validated && (inputWord == "" || inputWord == null) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                            sx: {
                                fontSize: "medium",
                                fontWeight: "bold",
                                color: "red",
                                paddingTop: "5px",
                                paddingLeft: "1rem"
                            },
                            children: "Word is required!"
                        }) : null
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    backgroundColor: theme === "dark" ? "#303030 !important" : "#fff",
                    padding: "30px 0 30px 0",
                    marginTop: "2rem",
                    borderRadius: "4px 4px 4px 4px"
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                    maxWidth: "lg",
                    children: [
                        loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Loader__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: !!wordApiData.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        sx: {
                                            "& .wordTxt": {
                                                fontSize: "56px",
                                                color: "orange",
                                                fontWeight: "900",
                                                fontFamily: '"Nunito",sans-serif',
                                                textTransform: "capitalize"
                                            }
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "wordTxt",
                                            children: slug
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                        container: true,
                                        spacing: 4,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 9,
                                                children: !!wordApiData.length && (wordApiData === null || wordApiData === void 0 ? void 0 : wordApiData.map((item, index)=>{
                                                    var ref, ref1, ref2, ref3;
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                        sx: {
                                                            marginTop: "20px",
                                                            backgroundColor: "#d1d1d1",
                                                            borderRadius: "22px",
                                                            padding: "34px 34px 34px 34px",
                                                            minHeight: "200px",
                                                            "& p": {
                                                                fontFamily: '"Nunito",sans-serif',
                                                                marginBottom: "8px"
                                                            }
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                        children: `Definition of ${item === null || item === void 0 ? void 0 : item.word}: `
                                                                    }),
                                                                    item === null || item === void 0 ? void 0 : item.definition
                                                                ]
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.synonyms) !== "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                    children: `Synonyms of ${slug}: `
                                                                })
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.synonyms) === "" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                                sx: {
                                                                    width: "100%",
                                                                    display: "flex",
                                                                    alignItems: "center",
                                                                    gap: 1,
                                                                    flexWrap: "wrap",
                                                                    paddingBottom: "5px",
                                                                    "& p": {
                                                                        background: "white",
                                                                        padding: "0.5rem",
                                                                        borderRadius: "0.25rem",
                                                                        textTransform: "capitalize",
                                                                        cursor: "pointer",
                                                                        "&:hover": {
                                                                            backgroundColor: "rgba(180,180,180,1)",
                                                                            textDecoration: "underline"
                                                                        }
                                                                    }
                                                                },
                                                                children: (item === null || item === void 0 ? void 0 : item.synonyms) && (item === null || item === void 0 ? void 0 : (ref = item.synonyms) === null || ref === void 0 ? void 0 : ref.map((data, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        onClick: ()=>router.push(`${data}`),
                                                                        children: data
                                                                    }, index)))
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.has_parts) !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                        children: "Has Parts: "
                                                                    }),
                                                                    (item === null || item === void 0 ? void 0 : item.has_parts) === "" ? null : item === null || item === void 0 ? void 0 : (ref1 = item.has_parts) === null || ref1 === void 0 ? void 0 : ref1.toString()
                                                                ]
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.is_a_type_of) !== "" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                        children: `${slug} is a Type of: `
                                                                    }),
                                                                    (item === null || item === void 0 ? void 0 : item.is_a_type_of) === "" ? null : item === null || item === void 0 ? void 0 : (ref2 = item.is_a_type_of) === null || ref2 === void 0 ? void 0 : ref2.toString()
                                                                ]
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.examples) !== "" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                                                    children: `Examples of ${slug}: `
                                                                })
                                                            }),
                                                            (item === null || item === void 0 ? void 0 : item.examples) === "" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                                style: {
                                                                    paddingLeft: "2rem"
                                                                },
                                                                children: item === null || item === void 0 ? void 0 : (ref3 = item.examples) === null || ref3 === void 0 ? void 0 : ref3.map((data, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("q", {
                                                                                style: {
                                                                                    fontSize: "16px",
                                                                                    fontFamily: '"Nunito",sans-serif'
                                                                                },
                                                                                children: data
                                                                            })
                                                                        })
                                                                    }, index))
                                                            })
                                                        ]
                                                    }, index);
                                                }))
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 3,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                    sx: {
                                                        position: "relative",
                                                        marginTop: "20px",
                                                        backgroundColor: "#d1d1d1",
                                                        borderRadius: "22px",
                                                        padding: "10px 30px 30px 30px",
                                                        minHeight: "200px"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                            sx: {
                                                                textAlign: "center",
                                                                paddingBottom: "10px",
                                                                "& .wordTxt": {
                                                                    fontSize: "40px",
                                                                    fontWeight: "900",
                                                                    fontFamily: '"Nunito",sans-serif',
                                                                    textTransform: "capitalize",
                                                                    color: "orange"
                                                                }
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "wordTxt",
                                                                children: "Rhymes"
                                                            })
                                                        }),
                                                        !!wordApiData.length && (wordApiData === null || wordApiData === void 0 ? void 0 : (ref = wordApiData[0]) === null || ref === void 0 ? void 0 : ref.rhymes) === "" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                            sx: {
                                                                "& .theWord": {
                                                                    fontWeight: 500,
                                                                    fontFamily: '"Nunito",sans-serif',
                                                                    width: "100%",
                                                                    fontSize: "16px",
                                                                    padding: "5px 7px 5px 11px",
                                                                    marginBottom: "10px",
                                                                    transition: ".3s ease",
                                                                    cursor: "pointer",
                                                                    borderRadius: "75px",
                                                                    backgroundColor: "rgba(255,255,255,1)",
                                                                    color: "black",
                                                                    display: "flex",
                                                                    alignItems: "center",
                                                                    "&:hover": {
                                                                        backgroundColor: "rgba(180,180,180,1)"
                                                                    }
                                                                }
                                                            },
                                                            children: (ref1 = wordApiData[0]) === null || ref1 === void 0 ? void 0 : (ref2 = ref1.rhymes) === null || ref2 === void 0 ? void 0 : ref2.map((data, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                    onClick: ()=>{
                                                                        if (slug.toLowerCase() != data.toLowerCase()) {
                                                                            setIsPageLoaded(false);
                                                                            setTimeout(()=>{
                                                                                router.push(`${data}`);
                                                                            }, 1000);
                                                                        }
                                                                    },
                                                                    className: "theWord",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                            sx: {
                                                                                fontSize: "16px",
                                                                                marginRight: "10px"
                                                                            }
                                                                        }),
                                                                        data
                                                                    ]
                                                                }, index))
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                sx: {
                                    fontSize: "2rem",
                                    fontWeight: "bold",
                                    color: "red",
                                    textAlign: "center",
                                    fontFamily: '"Nunito",sans-serif'
                                },
                                children: `No word details found for ${slug}!`
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.Toaster, {
                toastOptions: {
                    style: {
                        fontFamily: '"Nunito",sans-serif'
                    }
                },
                position: "top-right"
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DictionarySlug);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_dictionary_DictionarySlug__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(85);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_dictionary_DictionarySlug__WEBPACK_IMPORTED_MODULE_1__]);
_components_dictionary_DictionarySlug__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function DetailPage({ wordData , slug , loading  }) {
    console.log(wordData);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Create Next App"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dictionary_DictionarySlug__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    wordApiData: wordData,
                    slug: slug,
                    loading: loading
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailPage);
async function getServerSideProps(context) {
    const { params  } = context;
    const { slug  } = params;
    let loading = true;
    // Fetch data from the server
    const res = await fetch(`https://api.browseword.com/api/search?word=${slug}`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    });
    const data = await res.json();
    console.log("ddddd", data);
    loading = false;
    return {
        props: {
            wordData: data,
            slug: slug,
            loading
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 17:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 48:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 924:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [268,565], () => (__webpack_exec__(9)));
module.exports = __webpack_exports__;

})();