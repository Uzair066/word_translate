"use strict";
(() => {
var exports = {};
exports.id = 425;
exports.ids = [425];
exports.modules = {

/***/ 433:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ TopWords),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(17);
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_);
// EXTERNAL MODULE: ./context/context.js
var context = __webpack_require__(268);
;// CONCATENATED MODULE: ./components/top200/top200.jsx






function Top200({ top200  }) {
    const { setIsPageLoaded  } = (0,external_react_.useContext)(context/* Message_data */.L);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
        sx: {
            marginTop: "130px",
            position: "relative",
            backgroundColor: "#d1d1d1",
            borderRadius: "22px",
            padding: "37px 34px 34px 34px",
            minHeight: "349px"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                sx: {
                    position: "absolute",
                    width: "300px",
                    top: "-55px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    "& .wordTxt": {
                        fontSize: "56px",
                        left: "0",
                        top: "0",
                        color: "orange",
                        position: "absolute",
                        fontWeight: "900",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .ofTxt": {
                        fontSize: "22px",
                        left: "-3px",
                        top: "60px",
                        position: "absolute",
                        color: "#ffffff",
                        fontWeight: "700",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .theTxt": {
                        fontSize: "41px",
                        left: "85px",
                        top: "35px",
                        position: "absolute",
                        color: "#021f39",
                        fontFamily: "'MondayFont', cursive",
                        whiteSpace: "nowrap",
                        fontWeight: "600"
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "wordTxt",
                        children: "TOP 200"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "theTxt",
                        children: "words"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                container: true,
                spacing: 2,
                sx: {
                    marginTop: "0.5rem"
                },
                children: !!top200.length && top200.map((item, index)=>{
                    /*#__PURE__*/ return jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 3,
                        xl: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: `/en/${item === null || item === void 0 ? void 0 : item.word}-meaning-in-hindi`,
                            onClick: ()=>setIsPageLoaded(false),
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Box, {
                                sx: {
                                    borderRadius: "0.25rem",
                                    cursor: "pointer",
                                    display: "flex",
                                    alignItems: "center",
                                    backgroundColor: "white",
                                    padding: "0.5rem",
                                    "&:hover": {
                                        backgroundColor: "rgba(180,180,180,1)"
                                    },
                                    "& p": {
                                        textTransform: "capitalize",
                                        fontSize: ".875rem",
                                        lineHeight: "1.25rem",
                                        margin: "0px",
                                        fontFamily: '"Nunito", sans-serif'
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Search_default()), {
                                        sx: {
                                            fontSize: "16px",
                                            marginRight: "10px"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: item === null || item === void 0 ? void 0 : item.word
                                    })
                                ]
                            })
                        })
                    }, index);
                })
            })
        ]
    });
}
/* harmony default export */ const top200 = (Top200);

;// CONCATENATED MODULE: ./pages/top200/index.js



function TopWords({ posts  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Create Next App"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(top200, {
                    top200: posts
                })
            })
        ]
    });
}
const getServerSideProps = async ()=>{
    const res = await fetch("https://api.browseword.com/api/top30words?limit=200");
    const posts = await res.json();
    return {
        props: {
            posts: posts || []
        }
    };
};


/***/ }),

/***/ 17:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [268], () => (__webpack_exec__(433)));
module.exports = __webpack_exports__;

})();