"use strict";
exports.id = 965;
exports.ids = [965];
exports.modules = {

/***/ 965:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




function Alphabets() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { slug  } = router.query;
    const alphabetsArray = [
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "I",
        "J",
        "K",
        "L",
        "M",
        "N",
        "O",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z", 
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            marginTop: "63px",
            position: "relative",
            backgroundColor: "#d1d1d1",
            borderRadius: "22px",
            padding: "37px 34px 34px 34px"
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    position: "absolute",
                    width: "270px",
                    top: "-55px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    "& .wordTxt": {
                        fontSize: "56px",
                        left: "0",
                        top: "0",
                        color: "orange",
                        position: "absolute",
                        fontWeight: "900",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .ofTxt": {
                        fontSize: "22px",
                        left: "-3px",
                        top: "60px",
                        position: "absolute",
                        color: "#ffffff",
                        fontWeight: "700",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .theTxt": {
                        fontSize: "41px",
                        left: "40px",
                        top: "35px",
                        position: "absolute",
                        color: "#021f39",
                        fontFamily: "'MondayFont', cursive",
                        whiteSpace: "nowrap",
                        fontWeight: "600"
                    }
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "wordTxt",
                        children: "BROWSE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "theTxt",
                        children: "Dictionary"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    marginTop: "0.5rem",
                    display: "flex",
                    alignItems: "center",
                    columnGap: 8,
                    rowGap: 2,
                    flexWrap: "wrap"
                },
                children: alphabetsArray.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        onClick: ()=>{
                            if (slug !== undefined) {
                                router.push(`/en/dictionary/${slug}/1?startWith=${item}`);
                            } else {
                                router.push(`/alphabets/1?startWith=${item}`);
                            }
                        },
                        sx: {
                            borderRadius: "0.25rem",
                            height: "2.5rem",
                            width: "2.5rem",
                            cursor: "pointer",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            backgroundColor: "white",
                            "&:hover": {
                                backgroundColor: "rgba(180,180,180,1)"
                            },
                            "& p": {
                                textTransform: "capitalize",
                                margin: "0px",
                                fontFamily: '"Nunito", sans-serif'
                            }
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: item
                        })
                    }, item))
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Alphabets);


/***/ })

};
;