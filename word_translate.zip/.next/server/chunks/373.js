"use strict";
exports.id = 373;
exports.ids = [373];
exports.modules = {

/***/ 373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(17);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Pagination__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(216);
/* harmony import */ var _mui_material_Pagination__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Pagination__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _context_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(268);







function StartAlphabet({ apiData  }) {
    var ref, ref1, ref2, ref3;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { isPageLoaded , setIsPageLoaded  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context_context__WEBPACK_IMPORTED_MODULE_6__/* .Message_data */ .L);
    const { slug , pageNumber , startWith  } = router.query;
    const { 0: page , 1: setpage  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setpage(+pageNumber);
    }, [
        pageNumber
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            marginTop: "90px",
            position: "relative",
            backgroundColor: "#d1d1d1",
            borderRadius: "22px",
            padding: "37px 34px 34px 34px",
            minHeight: "200px"
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    position: "absolute",
                    width: "170px",
                    top: "-55px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    "& .wordTxt": {
                        fontSize: "56px",
                        left: "0",
                        top: "0",
                        color: "orange",
                        position: "absolute",
                        fontWeight: "900",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .ofTxt": {
                        fontSize: "22px",
                        left: "-3px",
                        top: "60px",
                        position: "absolute",
                        color: "#ffffff",
                        fontWeight: "700",
                        fontFamily: '"Nunito",sans-serif'
                    },
                    "& .theTxt": {
                        fontSize: "41px",
                        left: "110px",
                        top: "45px",
                        position: "absolute",
                        color: "#021f39",
                        fontFamily: "'MondayFont', cursive",
                        whiteSpace: "nowrap",
                        fontWeight: "600"
                    }
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "wordTxt",
                        children: "Word"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "ofTxt",
                        children: "Start with"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "theTxt",
                        children: startWith || "A"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                container: true,
                spacing: 2,
                sx: {
                    marginTop: "0.5rem"
                },
                children: !!(apiData === null || apiData === void 0 ? void 0 : (ref = apiData.data) === null || ref === void 0 ? void 0 : ref.length) && (apiData === null || apiData === void 0 ? void 0 : (ref1 = apiData.data) === null || ref1 === void 0 ? void 0 : ref1.map((item, index)=>{
                    /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        lg: 3,
                        xl: 3,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                            sx: {
                                borderRadius: "0.25rem",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                backgroundColor: "white",
                                padding: "0.5rem",
                                "&:hover": {
                                    backgroundColor: "rgba(180,180,180,1)"
                                },
                                "& p": {
                                    textTransform: "capitalize",
                                    fontSize: ".875rem",
                                    lineHeight: "1.25rem",
                                    margin: "0px",
                                    fontFamily: '"Nunito", sans-serif'
                                }
                            },
                            onClick: ()=>{
                                if (slug !== undefined) {
                                    setIsPageLoaded(false);
                                    setTimeout(()=>{
                                        router.push(`/en/${item === null || item === void 0 ? void 0 : item.word}-${slug === "english-to-urdu" ? "meaning-in-urdu" : slug === "english-to-punjabi" ? "meaning-in-punjabi" : slug === "english-to-hindi" ? "meaning-in-hindi" : slug === "english-to-tamil" ? "meaning-in-tamil" : slug === "english-to-telugu" ? "meaning-in-telugu" : slug === "english-to-bengali" ? "meaning-in-bengali" : slug === "english-to-kannada" ? "meaning-in-kannada" : slug === "english-to-marathi" ? "meaning-in-marathi" : slug === "english-to-malayalam" ? "meaning-in-malayalam" : slug === "english-to-gujarati" ? "meaning-in-gujarati" : null}`);
                                    }, 1000);
                                } else {
                                    setIsPageLoaded(false);
                                    setTimeout(()=>{
                                        router.push(`/dictionary/${item === null || item === void 0 ? void 0 : item.word}`);
                                    }, 1000);
                                }
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    sx: {
                                        fontSize: "16px",
                                        marginRight: "10px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: item === null || item === void 0 ? void 0 : item.word
                                })
                            ]
                        })
                    }, index);
                }))
            }),
            !!(apiData === null || apiData === void 0 ? void 0 : (ref2 = apiData.data) === null || ref2 === void 0 ? void 0 : ref2.length) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                sx: {
                    paddingTop: "2rem",
                    display: "flex",
                    justifyContent: "end",
                    "& .Mui-selected": {
                        backgroundColor: "orange !important",
                        color: "white !important",
                        fontWeight: "bold",
                        borderColor: "orange !important"
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Pagination__WEBPACK_IMPORTED_MODULE_5___default()), {
                    count: Math.ceil((apiData === null || apiData === void 0 ? void 0 : (ref3 = apiData.count) === null || ref3 === void 0 ? void 0 : ref3.length) / 20),
                    page: page,
                    onChange: (event, value)=>{
                        if (slug !== undefined) {
                            router.push(`/en/dictionary/${slug}/${value}?startWith=${startWith}`);
                        } else {
                            router.push(`/alphabets/${value}?startWith=${startWith}`);
                        }
                    },
                    variant: "outlined",
                    shape: "rounded"
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StartAlphabet);


/***/ })

};
;