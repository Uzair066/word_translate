(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[552],{4914:function(i,e,t){(window.__NEXT_P=window.__NEXT_P||[]).push(["/en/[wordToTranslate]",function(){return t(3445)}])},3445:function(i,e,t){"use strict";t.r(e),t.d(e,{__N_SSP:function(){return h},default:function(){return y}});var n=t(5893),o=t(3156),a=t(5616),l=t(5441),r=t(9417),s=t(6886),d=t(7294),c=t(1163),u=t(2761),p=t(6501),m=t(4268),f=t(9061);var x=function(i){var e,t,x,g,v=i.englishData,h=i.wordApiData,y=i.wordToTranslate,b=(0,d.useContext)(m.L).theme,j=(0,c.useRouter)(),w=(0,d.useState)(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]),k=w[0],T=w[1],_=(0,d.useState)(!0),N=_[0],z=_[1],S=(0,d.useState)(!1),E=S[0],Z=(S[1],function(){return""==k||null==k?(z(!1),!1):(z(!0),!0)});return(0,d.useEffect)((function(){T(null===y||void 0===y?void 0:y.split("-meaning-in-")[0])}),[y,h]),(0,n.jsxs)(o.Z,{maxWidth:"lg",sx:{paddingBottom:"90px"},children:[(0,n.jsx)(a.Z,{sx:{backgroundColor:"dark"===b?"#303030 !important":"#fff !important",padding:"30px 0 30px 0",marginTop:"90px",borderRadius:"4px 4px 4px 4px","& h1":{fontSize:"1.5rem",fontWeight:"600",color:"dark"===b?"white":"black",fontFamily:'"Nunito", sans-serif',margin:"unset",paddingBottom:"10px"}},children:(0,n.jsxs)(o.Z,{maxWidth:"sm",children:[(0,n.jsx)("h1",{children:"Look up a word, learn it forever."}),(0,n.jsx)("form",{onSubmit:function(i){i.preventDefault(),Z()&&j.push("".concat(k,"-").concat("urdu"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-urdu":"punjabi"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-punjabi":"hindi"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-hindi":"tamil"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-tamil":"telugu"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-telugu":"bengali"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-bengali":"kannada"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-kannada":"marathi"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-marathi":"malayalam"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-malayalam":"gujarati"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])?"meaning-in-gujarati":null))},children:(0,n.jsxs)(a.Z,{sx:{display:"flex",alignItems:"center",gap:1},children:[(0,n.jsx)(l.Z,{hiddenLabel:!0,size:"small",value:k,onChange:function(i){return T(i.target.value)},sx:{width:"100%",background:"white",borderRadius:"5px",fontSize:"3rem"},type:"text",error:!N&&(""==k||null==k),inputProps:{placeholder:"Enter a word"}}),(0,n.jsx)(r.Z,{variant:"contained",size:"large",type:"submit",sx:{height:"40px",background:"orange","&:hover":{background:"orange"}},children:(0,n.jsx)(u.Z,{})})]})}),N||""!=k&&null!=k?null:(0,n.jsx)(a.Z,{sx:{fontSize:"medium",fontWeight:"bold",color:"red",paddingTop:"5px",paddingLeft:"1rem"},children:"Word is required!"})]})}),(0,n.jsx)(a.Z,{sx:{backgroundColor:"dark"===b?"#303030 !important":"#fff",padding:"30px 0 30px 0",marginTop:"2rem",borderRadius:"4px 4px 4px 4px"},children:(0,n.jsxs)(o.Z,{maxWidth:"lg",children:[E&&(0,n.jsx)(f.Z,{}),(0,n.jsx)(n.Fragment,{children:h.length?(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(a.Z,{sx:{"& .wordTxt":{fontSize:"50px",color:"orange",fontWeight:"700",fontFamily:'"Nunito",sans-serif',textTransform:"capitalize",textAlign:"center"},"& span":{fontSize:"50px",color:"dark"===b?"#fff !important":"#303030 !important",fontWeight:"500",fontFamily:'"Nunito",sans-serif',textTransform:"capitalize"}},children:(0,n.jsxs)("p",{className:"wordTxt",children:[null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," ",(0,n.jsx)("span",{children:"Meaning in"})," ",null===y||void 0===y?void 0:y.split("-meaning-in-")[1]]})}),(0,n.jsx)(a.Z,{sx:{"& .wordTxt":{fontSize:"20px",color:"orange",fontWeight:"500",fontFamily:'"Nunito",sans-serif',textTransform:"capitalize",textAlign:"center"}},children:(0,n.jsxs)("p",{className:"wordTxt",children:["kannada"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u0c87\u0ca6\u0cb0 \u0ca8\u0cbf\u0c9c\u0cb5\u0cbe\u0ca6 \u0c85\u0cb0\u0ccd\u0ca5\u0cb5\u0ca8\u0ccd\u0ca8\u0cc1 \u0ca4\u0cbf\u0cb3\u0cbf\u0caf\u0cbf\u0cb0\u0cbf ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0cb8\u0cb0\u0cb3 \u0c89\u0ca6\u0cbe\u0cb9\u0cb0\u0ca3\u0cc6\u0c97\u0cb3\u0cc1 \u0cae\u0ca4\u0ccd\u0ca4\u0cc1 \u0cb5\u0ccd\u0caf\u0cbe\u0c96\u0ccd\u0caf\u0cbe\u0ca8\u0c97\u0cb3\u0cca\u0c82\u0ca6\u0cbf\u0c97\u0cc6"),"hindi"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u091c\u093e\u0928\u0947\u0902 \u0907\u0938\u0915\u093e \u0938\u0939\u0940 \u092e\u0924\u0932\u092c ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0938\u0930\u0932 \u0909\u0926\u093e\u0939\u0930\u0923\u094b\u0902 \u0914\u0930 \u092a\u0930\u093f\u092d\u093e\u0937\u093e\u0913\u0902 \u0915\u0947 \u0938\u093e\u0925"),"tamil"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u0b8e\u0ba9\u0bcd\u0baa\u0ba4\u0ba9\u0bcd \u0b89\u0ba3\u0bcd\u0bae\u0bc8\u0baf\u0bbe\u0ba9 \u0b85\u0bb0\u0bcd\u0ba4\u0bcd\u0ba4\u0ba4\u0bcd\u0ba4\u0bc8 \u0b85\u0bb1\u0bbf\u0b95 ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0b8e\u0bb3\u0bbf\u0baf \u0b8e\u0b9f\u0bc1\u0ba4\u0bcd\u0ba4\u0bc1\u0b95\u0bcd\u0b95\u0bbe\u0b9f\u0bcd\u0b9f\u0bc1\u0b95\u0bb3\u0bcd \u0bae\u0bb1\u0bcd\u0bb1\u0bc1\u0bae\u0bcd \u0bb5\u0bb0\u0bc8\u0baf\u0bb1\u0bc8\u0b95\u0bb3\u0bc1\u0b9f\u0ba9\u0bcd"),"telugu"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u0c2f\u0c4a\u0c15\u0c4d\u0c15 \u0c28\u0c3f\u0c1c\u0c2e\u0c48\u0c28 \u0c05\u0c30\u0c4d\u0c25\u0c02 \u0c24\u0c46\u0c32\u0c41\u0c38\u0c41\u0c15\u0c4b\u0c02\u0c21\u0c3f ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0c38\u0c3e\u0c27\u0c3e\u0c30\u0c23 \u0c09\u0c26\u0c3e\u0c39\u0c30\u0c23\u0c32\u0c41 \u0c2e\u0c30\u0c3f\u0c2f\u0c41 \u0c28\u0c3f\u0c30\u0c4d\u0c35\u0c1a\u0c28\u0c3e\u0c32\u0c24\u0c4b"),"bengali"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u098f\u09b0 \u09aa\u09cd\u09b0\u0995\u09c3\u09a4 \u0985\u09b0\u09cd\u09a5 \u099c\u09be\u09a8\u09c1\u09a8 ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u09b8\u09b9\u099c \u0989\u09a6\u09be\u09b9\u09b0\u09a3 \u098f\u09ac\u0982 \u09b8\u0982\u099c\u09cd\u099e\u09be \u09b8\u09b9"),"marathi"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u091a\u093e \u0916\u0930\u093e \u0905\u0930\u094d\u0925 \u091c\u093e\u0923\u0942\u0928 \u0918\u094d\u092f\u093e ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0938\u093e\u0927\u0940 \u0909\u0926\u093e\u0939\u0930\u0923\u0947 \u0906\u0923\u093f \u0935\u094d\u092f\u093e\u0916\u094d\u092f\u093e \u0938\u0939"),"malayalam"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u0d0e\u0d28\u0d4d\u0d28\u0d24\u0d3f\u0d7b\u0d4d\u0d31\u0d46 \u0d2f\u0d25\u0d3e\u0d7c\u0d24\u0d4d\u0d25 \u0d05\u0d7c\u0d24\u0d4d\u0d25\u0d02 \u0d2e\u0d28\u0d38\u0d4d\u0d38\u0d3f\u0d32\u0d3e\u0d15\u0d4d\u0d15\u0d41\u0d15 ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0d32\u0d33\u0d3f\u0d24\u0d2e\u0d3e\u0d2f \u0d09\u0d26\u0d3e\u0d39\u0d30\u0d23\u0d19\u0d4d\u0d19\u0d33\u0d41\u0d02 \u0d28\u0d3f\u0d7c\u0d35\u0d1a\u0d28\u0d19\u0d4d\u0d19\u0d33\u0d41\u0d02 \u0d38\u0d39\u0d3f\u0d24\u0d02"),"gujrati"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u0aa8\u0acb \u0ab8\u0abe\u0a9a\u0acb \u0a85\u0ab0\u0acd\u0aa5 \u0a9c\u0abe\u0aa3\u0acb ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0ab8\u0ab0\u0ab3 \u0a89\u0aa6\u0abe\u0ab9\u0ab0\u0aa3\u0acb \u0a85\u0aa8\u0ac7 \u0ab5\u0acd\u0aaf\u0abe\u0a96\u0acd\u0aaf\u0abe\u0a93 \u0ab8\u0abe\u0aa5\u0ac7"),"punjabi"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u0a26\u0a3e \u0a38\u0a39\u0a40 \u0a05\u0a30\u0a25 \u0a1c\u0a3e\u0a23\u0a4b ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0a38\u0a27\u0a3e\u0a30\u0a28 \u0a09\u0a26\u0a3e\u0a39\u0a30\u0a23\u0a3e\u0a02 \u0a05\u0a24\u0a47 \u0a2a\u0a30\u0a3f\u0a2d\u0a3e\u0a38\u0a3c\u0a3e\u0a35\u0a3e\u0a02 \u0a26\u0a47 \u0a28\u0a3e\u0a32"),"urdu"===(null===y||void 0===y?void 0:y.split("-meaning-in-")[1])&&"\u06a9\u06d2 \u062d\u0642\u06cc\u0642\u06cc \u0645\u0639\u0646\u06cc \u062c\u0627\u0646\u06cc\u06ba\u06d4 ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," \u0633\u0627\u062f\u06c1 \u0645\u062b\u0627\u0644\u0648\u06ba \u0627\u0648\u0631 \u062a\u0639\u0631\u06cc\u0641\u0648\u06ba \u06a9\u06d2 \u0633\u0627\u062a\u06be")]})}),(0,n.jsxs)(a.Z,{sx:{"& .wordTxt":{fontSize:"56px",color:"orange",fontWeight:"900",fontFamily:'"Nunito",sans-serif',textTransform:"capitalize"},"& span":{fontSize:"x-large",color:"dark"===b?"#fff !important":"#303030 !important",fontWeight:"700",fontFamily:'"Nunito",sans-serif',textTransform:"capitalize"}},children:[(0,n.jsx)("p",{className:"wordTxt",children:null===h||void 0===h||null===(e=h[0])||void 0===e?void 0:e.word_translated}),(0,n.jsx)("span",{children:null===y||void 0===y?void 0:y.split("-meaning-in-")[0]})]}),(0,n.jsxs)(s.ZP,{container:!0,spacing:4,children:[(0,n.jsx)(s.ZP,{item:!0,xs:12,md:9,children:!!h.length&&(null===h||void 0===h?void 0:h.map((function(i,e){var t,o,l,r,s,d,c,u,p,m,f;return(0,n.jsxs)(a.Z,{sx:{marginTop:"20px",backgroundColor:"#d1d1d1",borderRadius:"22px",padding:"34px 34px 34px 34px",minHeight:"200px","& p":{fontFamily:'"Nunito",sans-serif'}},children:[(0,n.jsx)("p",{children:(0,n.jsx)("b",{children:"Definition of ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0],": ")})}),(0,n.jsxs)(a.Z,{sx:{display:"flex",marginBottom:"8px",flexWrap:"wrap",flexDirection:"column","& p":{marginBottom:"0px"}},children:[(0,n.jsx)("p",{children:null===i||void 0===i?void 0:i.definition}),(0,n.jsx)("p",{style:{fontSize:"small",color:"#716f6f"},children:null===v||void 0===v||null===(t=v[e])||void 0===t?void 0:t.definition})]}),""!==(null===i||void 0===i?void 0:i.synonyms)&&(0,n.jsx)("p",{children:(0,n.jsx)("b",{children:"Synonyms of ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0],": ")})}),""===(null===i||void 0===i?void 0:i.synonyms)?null:(0,n.jsx)(a.Z,{sx:{width:"100%",display:"flex",alignItems:"center",gap:1,flexWrap:"wrap",paddingBottom:"5px","& .textToClick":{background:"white",padding:"0.5rem",borderRadius:"0.25rem",textTransform:"capitalize",cursor:"pointer","&:hover":{backgroundColor:"rgba(180,180,180,1)"}}},children:null===i||void 0===i||null===(o=i.synonyms)||void 0===o?void 0:o.map((function(i,t){var o,l,r;return(0,n.jsxs)(a.Z,{className:"textToClick",onClick:function(){var i,n;return j.push("/en/".concat(null===v||void 0===v||null===(i=v[e])||void 0===i||null===(n=i.synonyms)||void 0===n?void 0:n[t],"-meaning-in-").concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[1]))},children:[(0,n.jsx)("p",{children:i}),(0,n.jsx)("p",{style:{fontSize:"small",color:"#716f6f"},children:""!==(null===v||void 0===v||null===(o=v[e])||void 0===o?void 0:o.synonyms)&&(null===v||void 0===v||null===(l=v[e])||void 0===l||null===(r=l.synonyms)||void 0===r?void 0:r[t])})]},t)}))}),""!==(null===i||void 0===i?void 0:i.has_parts)&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("p",{children:(0,n.jsx)("b",{children:"Has Parts: "})}),(0,n.jsxs)(a.Z,{sx:{marginBottom:"8px"},children:[(0,n.jsx)("p",{children:""===(null===i||void 0===i?void 0:i.has_parts)?null:null===i||void 0===i||null===(l=i.has_parts)||void 0===l?void 0:l.toString()}),(0,n.jsx)("p",{style:{fontSize:"small",color:"#716f6f"},children:""===(null===v||void 0===v||null===(r=v[e])||void 0===r?void 0:r.has_parts)?null:null===v||void 0===v||null===(s=v[e])||void 0===s||null===(d=s.has_parts)||void 0===d?void 0:d.toString()})]})]}),""!==(null===i||void 0===i?void 0:i.is_a_type_of)&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("p",{children:(0,n.jsx)("b",{children:"".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0]," is a Type of: ")})}),(0,n.jsxs)(a.Z,{sx:{marginBottom:"8px"},children:[(0,n.jsx)("p",{children:""===(null===i||void 0===i?void 0:i.is_a_type_of)?null:null===i||void 0===i||null===(c=i.is_a_type_of)||void 0===c?void 0:c.toString()}),(0,n.jsx)("p",{style:{fontSize:"small",color:"#716f6f"},children:""===(null===v||void 0===v||null===(u=v[e])||void 0===u?void 0:u.is_a_type_of)?null:null===v||void 0===v||null===(p=v[e])||void 0===p||null===(m=p.is_a_type_of)||void 0===m?void 0:m.toString()})]})]}),""!==(null===i||void 0===i?void 0:i.examples)&&(0,n.jsx)("p",{children:(0,n.jsx)("b",{children:"Examples of ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0],": ")})}),""===(null===i||void 0===i?void 0:i.examples)?null:(0,n.jsx)("ul",{style:{paddingLeft:"2rem"},children:null===i||void 0===i||null===(f=i.examples)||void 0===f?void 0:f.map((function(i,t){var o,a,l;return(0,n.jsxs)("li",{children:[(0,n.jsx)("span",{style:{width:"100%",display:"block"},children:(0,n.jsx)("i",{children:(0,n.jsx)("q",{style:{fontSize:"16px",fontFamily:'"Nunito",sans-serif'},children:i})})}),(0,n.jsx)("span",{children:(0,n.jsx)("i",{children:(0,n.jsx)("q",{style:{fontSize:"small",color:"#716f6f",fontFamily:'"Nunito",sans-serif'},children:""!==(null===v||void 0===v||null===(o=v[e])||void 0===o?void 0:o.examples)&&(null===v||void 0===v||null===(a=v[e])||void 0===a||null===(l=a.examples)||void 0===l?void 0:l[t])})})})]},t)}))})]},e)})))}),(0,n.jsx)(s.ZP,{item:!0,xs:12,md:3,children:(0,n.jsxs)(a.Z,{sx:{position:"relative",marginTop:"20px",backgroundColor:"#d1d1d1",borderRadius:"22px",padding:"10px 30px 30px 30px",minHeight:"200px"},children:[(0,n.jsx)(a.Z,{sx:{textAlign:"center",paddingBottom:"10px","& .wordTxt":{fontSize:"40px",fontWeight:"900",fontFamily:'"Nunito",sans-serif',textTransform:"capitalize",color:"orange"}},children:(0,n.jsx)("p",{className:"wordTxt",children:"Rhymes"})}),h.length&&""===(null===h||void 0===h||null===(t=h[0])||void 0===t?void 0:t.rhymes)?null:(0,n.jsx)(a.Z,{sx:{"& .theWord":{fontWeight:500,fontFamily:'"Nunito",sans-serif',width:"100%",fontSize:"16px",padding:"5px 7px 5px 11px",marginBottom:"10px",transition:".3s ease",borderRadius:"75px",backgroundColor:"rgba(255,255,255,1)",color:"black",display:"flex",alignItems:"center",cursor:"pointer","&:hover":{backgroundColor:"rgba(180,180,180,1)"}}},children:null===(x=h[0])||void 0===x||null===(g=x.rhymes)||void 0===g?void 0:g.map((function(i,e){var t,o,a;return(0,n.jsxs)("p",{className:"theWord",onClick:function(){var i,t;return j.push("/en/".concat(null===v||void 0===v||null===(i=v[0])||void 0===i||null===(t=i.rhymes)||void 0===t?void 0:t[e],"-meaning-in-").concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[1]))},children:[(0,n.jsx)(u.Z,{sx:{fontSize:"16px",marginRight:"10px"}}),i,(0,n.jsx)("br",{}),""!==(null===v||void 0===v||null===(t=v[0])||void 0===t?void 0:t.rhymes)&&(null===v||void 0===v||null===(o=v[0])||void 0===o||null===(a=o.rhymes)||void 0===a?void 0:a[e])]},e)}))})]})})]})]}):(0,n.jsx)(a.Z,{sx:{fontSize:"2rem",fontWeight:"bold",color:"red",textAlign:"center",fontFamily:'"Nunito",sans-serif'},children:"No word details found for ".concat(null===y||void 0===y?void 0:y.split("-meaning-in-")[0],"!")})})]})}),(0,n.jsx)(p.x7,{toastOptions:{style:{fontFamily:'"Nunito",sans-serif'}},position:"top-right"})]})},g=t(9008),v=t.n(g);var h=!0,y=function(i){var e=i.engData,t=i.wordData,o=i.wordToTranslate;return console.log(t),(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)(v(),{children:[(0,n.jsx)("title",{children:"Create Next App"}),(0,n.jsx)("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),(0,n.jsx)("link",{rel:"icon",href:"/favicon.ico"})]}),(0,n.jsx)("main",{children:(0,n.jsx)(x,{wordToTranslate:o,englishData:e,wordApiData:t})})]})}},6501:function(i,e,t){"use strict";t.d(e,{x7:function(){return ti}});var n=t(7294);let o={data:""},a=i=>"object"==typeof window?((i?i.querySelector("#_goober"):window._goober)||Object.assign((i||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:i||o,l=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,r=/\/\*[^]*?\*\/|  +/g,s=/\n+/g,d=(i,e)=>{let t="",n="",o="";for(let a in i){let l=i[a];"@"==a[0]?"i"==a[1]?t=a+" "+l+";":n+="f"==a[1]?d(l,a):a+"{"+d(l,"k"==a[1]?"":e)+"}":"object"==typeof l?n+=d(l,e?e.replace(/([^,])+/g,(i=>a.replace(/(^:.*)|([^,])+/g,(e=>/&/.test(e)?e.replace(/&/g,i):i?i+" "+e:e)))):a):null!=l&&(a=/^--/.test(a)?a:a.replace(/[A-Z]/g,"-$&").toLowerCase(),o+=d.p?d.p(a,l):a+":"+l+";")}return t+(e&&o?e+"{"+o+"}":o)+n},c={},u=i=>{if("object"==typeof i){let e="";for(let t in i)e+=t+u(i[t]);return e}return i},p=(i,e,t,n,o)=>{let a=u(i),p=c[a]||(c[a]=(i=>{let e=0,t=11;for(;e<i.length;)t=101*t+i.charCodeAt(e++)>>>0;return"go"+t})(a));if(!c[p]){let e=a!==i?i:(i=>{let e,t,n=[{}];for(;e=l.exec(i.replace(r,""));)e[4]?n.shift():e[3]?(t=e[3].replace(s," ").trim(),n.unshift(n[0][t]=n[0][t]||{})):n[0][e[1]]=e[2].replace(s," ").trim();return n[0]})(i);c[p]=d(o?{["@keyframes "+p]:e}:e,t?"":"."+p)}let m=t&&c.g?c.g:null;return t&&(c.g=c[p]),((i,e,t,n)=>{n?e.data=e.data.replace(n,i):-1===e.data.indexOf(i)&&(e.data=t?i+e.data:e.data+i)})(c[p],e,n,m),p},m=(i,e,t)=>i.reduce(((i,n,o)=>{let a=e[o];if(a&&a.call){let i=a(t),e=i&&i.props&&i.props.className||/^go/.test(i)&&i;a=e?"."+e:i&&"object"==typeof i?i.props?"":d(i,""):!1===i?"":i}return i+n+(null==a?"":a)}),"");function f(i){let e=this||{},t=i.call?i(e.p):i;return p(t.unshift?t.raw?m(t,[].slice.call(arguments,1),e.p):t.reduce(((i,t)=>Object.assign(i,t&&t.call?t(e.p):t)),{}):t,a(e.target),e.g,e.o,e.k)}f.bind({g:1});let x,g,v,h=f.bind({k:1});function y(i,e){let t=this||{};return function(){let n=arguments;function o(a,l){let r=Object.assign({},a),s=r.className||o.className;t.p=Object.assign({theme:g&&g()},r),t.o=/ *go\d+/.test(s),r.className=f.apply(t,n)+(s?" "+s:""),e&&(r.ref=l);let d=i;return i[0]&&(d=r.as||i,delete r.as),v&&d[0]&&v(r),x(d,r)}return e?e(o):o}}var b=(i,e)=>(i=>"function"==typeof i)(i)?i(e):i,j=(()=>{let i=0;return()=>(++i).toString()})(),w=(()=>{let i;return()=>{if(void 0===i&&typeof window<"u"){let e=matchMedia("(prefers-reduced-motion: reduce)");i=!e||e.matches}return i}})(),k=new Map,T=i=>{if(k.has(i))return;let e=setTimeout((()=>{k.delete(i),S({type:4,toastId:i})}),1e3);k.set(i,e)},_=(i,e)=>{switch(e.type){case 0:return{...i,toasts:[e.toast,...i.toasts].slice(0,20)};case 1:return e.toast.id&&(i=>{let e=k.get(i);e&&clearTimeout(e)})(e.toast.id),{...i,toasts:i.toasts.map((i=>i.id===e.toast.id?{...i,...e.toast}:i))};case 2:let{toast:t}=e;return i.toasts.find((i=>i.id===t.id))?_(i,{type:1,toast:t}):_(i,{type:0,toast:t});case 3:let{toastId:n}=e;return n?T(n):i.toasts.forEach((i=>{T(i.id)})),{...i,toasts:i.toasts.map((i=>i.id===n||void 0===n?{...i,visible:!1}:i))};case 4:return void 0===e.toastId?{...i,toasts:[]}:{...i,toasts:i.toasts.filter((i=>i.id!==e.toastId))};case 5:return{...i,pausedAt:e.time};case 6:let o=e.time-(i.pausedAt||0);return{...i,pausedAt:void 0,toasts:i.toasts.map((i=>({...i,pauseDuration:i.pauseDuration+o})))}}},N=[],z={toasts:[],pausedAt:void 0},S=i=>{z=_(z,i),N.forEach((i=>{i(z)}))},E={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},Z=i=>(e,t)=>{let n=((i,e="blank",t)=>({createdAt:Date.now(),visible:!0,type:e,ariaProps:{role:"status","aria-live":"polite"},message:i,pauseDuration:0,...t,id:(null==t?void 0:t.id)||j()}))(e,i,t);return S({type:2,toast:n}),n.id},C=(i,e)=>Z("blank")(i,e);C.error=Z("error"),C.success=Z("success"),C.loading=Z("loading"),C.custom=Z("custom"),C.dismiss=i=>{S({type:3,toastId:i})},C.remove=i=>S({type:4,toastId:i}),C.promise=(i,e,t)=>{let n=C.loading(e.loading,{...t,...null==t?void 0:t.loading});return i.then((i=>(C.success(b(e.success,i),{id:n,...t,...null==t?void 0:t.success}),i))).catch((i=>{C.error(b(e.error,i),{id:n,...t,...null==t?void 0:t.error})})),i};var F=(i,e)=>{S({type:1,toast:{id:i,height:e}})},$=()=>{S({type:5,time:Date.now()})},D=i=>{let{toasts:e,pausedAt:t}=((i={})=>{let[e,t]=(0,n.useState)(z);(0,n.useEffect)((()=>(N.push(t),()=>{let i=N.indexOf(t);i>-1&&N.splice(i,1)})),[e]);let o=e.toasts.map((e=>{var t,n;return{...i,...i[e.type],...e,duration:e.duration||(null==(t=i[e.type])?void 0:t.duration)||(null==i?void 0:i.duration)||E[e.type],style:{...i.style,...null==(n=i[e.type])?void 0:n.style,...e.style}}}));return{...e,toasts:o}})(i);(0,n.useEffect)((()=>{if(t)return;let i=Date.now(),n=e.map((e=>{if(e.duration===1/0)return;let t=(e.duration||0)+e.pauseDuration-(i-e.createdAt);if(!(t<0))return setTimeout((()=>C.dismiss(e.id)),t);e.visible&&C.dismiss(e.id)}));return()=>{n.forEach((i=>i&&clearTimeout(i)))}}),[e,t]);let o=(0,n.useCallback)((()=>{t&&S({type:6,time:Date.now()})}),[t]),a=(0,n.useCallback)(((i,t)=>{let{reverseOrder:n=!1,gutter:o=8,defaultPosition:a}=t||{},l=e.filter((e=>(e.position||a)===(i.position||a)&&e.height)),r=l.findIndex((e=>e.id===i.id)),s=l.filter(((i,e)=>e<r&&i.visible)).length;return l.filter((i=>i.visible)).slice(...n?[s+1]:[0,s]).reduce(((i,e)=>i+(e.height||0)+o),0)}),[e]);return{toasts:e,handlers:{updateHeight:F,startPause:$,endPause:o,calculateOffset:a}}},W=h`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,A=h`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,O=h`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,P=y("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${i=>i.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${W} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${A} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${i=>i.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${O} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,I=h`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,R=y("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${i=>i.secondary||"#e0e0e0"};
  border-right-color: ${i=>i.primary||"#616161"};
  animation: ${I} 1s linear infinite;
`,B=h`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,L=h`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,H=y("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${i=>i.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${B} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${L} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${i=>i.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,M=y("div")`
  position: absolute;
`,q=y("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,U=h`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,X=y("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${U} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Y=({toast:i})=>{let{icon:e,type:t,iconTheme:o}=i;return void 0!==e?"string"==typeof e?n.createElement(X,null,e):e:"blank"===t?null:n.createElement(q,null,n.createElement(R,{...o}),"loading"!==t&&n.createElement(M,null,"error"===t?n.createElement(P,{...o}):n.createElement(H,{...o})))},G=i=>`\n0% {transform: translate3d(0,${-200*i}%,0) scale(.6); opacity:.5;}\n100% {transform: translate3d(0,0,0) scale(1); opacity:1;}\n`,J=i=>`\n0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}\n100% {transform: translate3d(0,${-150*i}%,-1px) scale(.6); opacity:0;}\n`,K=y("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Q=y("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,V=n.memo((({toast:i,position:e,style:t,children:o})=>{let a=i.height?((i,e)=>{let t=i.includes("top")?1:-1,[n,o]=w()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[G(t),J(t)];return{animation:e?`${h(n)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${h(o)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(i.position||e||"top-center",i.visible):{opacity:0},l=n.createElement(Y,{toast:i}),r=n.createElement(Q,{...i.ariaProps},b(i.message,i));return n.createElement(K,{className:i.className,style:{...a,...t,...i.style}},"function"==typeof o?o({icon:l,message:r}):n.createElement(n.Fragment,null,l,r))}));!function(i,e,t,n){d.p=e,x=i,g=t,v=n}(n.createElement);var ii=({id:i,className:e,style:t,onHeightUpdate:o,children:a})=>{let l=n.useCallback((e=>{if(e){let t=()=>{let t=e.getBoundingClientRect().height;o(i,t)};t(),new MutationObserver(t).observe(e,{subtree:!0,childList:!0,characterData:!0})}}),[i,o]);return n.createElement("div",{ref:l,className:e,style:t},a)},ei=f`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ti=({reverseOrder:i,position:e="top-center",toastOptions:t,gutter:o,children:a,containerStyle:l,containerClassName:r})=>{let{toasts:s,handlers:d}=D(t);return n.createElement("div",{style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...l},className:r,onMouseEnter:d.startPause,onMouseLeave:d.endPause},s.map((t=>{let l=t.position||e,r=((i,e)=>{let t=i.includes("top"),n=t?{top:0}:{bottom:0},o=i.includes("center")?{justifyContent:"center"}:i.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:w()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${e*(t?1:-1)}px)`,...n,...o}})(l,d.calculateOffset(t,{reverseOrder:i,gutter:o,defaultPosition:e}));return n.createElement(ii,{id:t.id,key:t.id,onHeightUpdate:d.updateHeight,className:t.visible?ei:"",style:r},"custom"===t.type?b(t.message,t):a?a(t):n.createElement(V,{toast:t,position:l}))})))}}},function(i){i.O(0,[164,441,774,888,179],(function(){return e=4914,i(i.s=e);var e}));var e=i.O();_N_E=e}]);