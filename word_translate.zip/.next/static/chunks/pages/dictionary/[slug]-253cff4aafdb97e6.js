(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[614],{6786:function(e,t,i){(window.__NEXT_P=window.__NEXT_P||[]).push(["/dictionary/[slug]",function(){return i(8267)}])},8267:function(e,t,i){"use strict";i.r(t),i.d(t,{__N_SSP:function(){return y},default:function(){return b}});var o=i(5893),r=i(3156),n=i(5616),a=i(5441),s=i(9417),l=i(6886),d=i(7294),c=i(1163),p=i(2761),u=i(6501),f=i(4268),m=i(9061);var x=function(e){var t,i,x,h=e.wordApiData,g=e.slug,y=(0,d.useContext)(f.L),b=y.theme,v=y.setIsPageLoaded,w=(0,c.useRouter)();console.log(h);var j=(0,d.useState)(g),k=j[0],E=j[1],N=(0,d.useState)(!0),_=N[0],C=N[1],z=(0,d.useState)(!0),T=z[0],Z=z[1],S=function(){return""==k||null==k?(C(!1),!1):(C(!0),!0)};return(0,d.useEffect)((function(){null===h?Z(!0):(E(g),Z(!1))}),[g,h]),(0,o.jsxs)(r.Z,{maxWidth:"lg",sx:{paddingBottom:"90px"},children:[(0,o.jsx)(n.Z,{sx:{backgroundColor:"dark"===b?"#303030 !important":"#fff !important",padding:"30px 0 30px 0",marginTop:"90px",borderRadius:"4px 4px 4px 4px","& h1":{fontSize:"1.5rem",fontWeight:"600",color:"dark"===b?"white":"black",fontFamily:'"Nunito", sans-serif',margin:"unset",paddingBottom:"10px"}},children:(0,o.jsxs)(r.Z,{maxWidth:"sm",children:[(0,o.jsx)("h1",{children:"Look up a word, learn it forever."}),(0,o.jsx)("form",{onSubmit:function(e){e.preventDefault(),S()&&g.toLowerCase()!=k.toLowerCase()&&(v(!1),setTimeout((function(){w.push("".concat(k))}),1e3))},children:(0,o.jsxs)(n.Z,{sx:{display:"flex",alignItems:"center",gap:1},children:[(0,o.jsx)(a.Z,{hiddenLabel:!0,size:"small",value:k,onChange:function(e){return E(e.target.value)},sx:{width:"100%",background:"white",borderRadius:"5px",fontSize:"3rem"},type:"text",error:!_&&(""==k||null==k),inputProps:{placeholder:"Enter a word"}}),(0,o.jsx)(s.Z,{variant:"contained",size:"large",type:"submit",sx:{height:"40px",background:"orange","&:hover":{background:"orange"}},children:(0,o.jsx)(p.Z,{})})]})}),_||""!=k&&null!=k?null:(0,o.jsx)(n.Z,{sx:{fontSize:"medium",fontWeight:"bold",color:"red",paddingTop:"5px",paddingLeft:"1rem"},children:"Word is required!"})]})}),(0,o.jsx)(n.Z,{sx:{backgroundColor:"dark"===b?"#303030 !important":"#fff",padding:"30px 0 30px 0",marginTop:"2rem",borderRadius:"4px 4px 4px 4px"},children:(0,o.jsxs)(r.Z,{maxWidth:"lg",children:[T&&(0,o.jsx)(m.Z,{}),(0,o.jsx)(o.Fragment,{children:h.length?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(n.Z,{sx:{"& .wordTxt":{fontSize:"56px",color:"orange",fontWeight:"900",fontFamily:'"Nunito",sans-serif',textTransform:"capitalize"}},children:(0,o.jsx)("p",{className:"wordTxt",children:g})}),(0,o.jsxs)(l.ZP,{container:!0,spacing:4,children:[(0,o.jsx)(l.ZP,{item:!0,xs:12,md:9,children:!!h.length&&(null===h||void 0===h?void 0:h.map((function(e,t){var i,r,a,s;return(0,o.jsxs)(n.Z,{sx:{marginTop:"20px",backgroundColor:"#d1d1d1",borderRadius:"22px",padding:"34px 34px 34px 34px",minHeight:"200px","& p":{fontFamily:'"Nunito",sans-serif',marginBottom:"8px"}},children:[(0,o.jsxs)("p",{children:[(0,o.jsx)("b",{children:"Definition of ".concat(null===e||void 0===e?void 0:e.word,": ")}),null===e||void 0===e?void 0:e.definition]}),""!==(null===e||void 0===e?void 0:e.synonyms)&&(0,o.jsx)("p",{children:(0,o.jsx)("b",{children:"Synonyms of ".concat(g,": ")})}),""===(null===e||void 0===e?void 0:e.synonyms)?null:(0,o.jsx)(n.Z,{sx:{width:"100%",display:"flex",alignItems:"center",gap:1,flexWrap:"wrap",paddingBottom:"5px","& p":{background:"white",padding:"0.5rem",borderRadius:"0.25rem",textTransform:"capitalize",cursor:"pointer","&:hover":{backgroundColor:"rgba(180,180,180,1)",textDecoration:"underline"}}},children:(null===e||void 0===e?void 0:e.synonyms)&&(null===e||void 0===e||null===(i=e.synonyms)||void 0===i?void 0:i.map((function(e,t){return(0,o.jsx)("p",{onClick:function(){return w.push("".concat(e))},children:e},t)})))}),""!==(null===e||void 0===e?void 0:e.has_parts)&&(0,o.jsxs)("p",{children:[(0,o.jsx)("b",{children:"Has Parts: "}),""===(null===e||void 0===e?void 0:e.has_parts)?null:null===e||void 0===e||null===(r=e.has_parts)||void 0===r?void 0:r.toString()]}),""!==(null===e||void 0===e?void 0:e.is_a_type_of)&&(0,o.jsxs)("p",{children:[(0,o.jsx)("b",{children:"".concat(g," is a Type of: ")}),""===(null===e||void 0===e?void 0:e.is_a_type_of)?null:null===e||void 0===e||null===(a=e.is_a_type_of)||void 0===a?void 0:a.toString()]}),""!==(null===e||void 0===e?void 0:e.examples)&&(0,o.jsx)("p",{children:(0,o.jsx)("b",{children:"Examples of ".concat(g,": ")})}),""===(null===e||void 0===e?void 0:e.examples)?null:(0,o.jsx)("ul",{style:{paddingLeft:"2rem"},children:null===e||void 0===e||null===(s=e.examples)||void 0===s?void 0:s.map((function(e,t){return(0,o.jsx)("li",{children:(0,o.jsx)("i",{children:(0,o.jsx)("q",{style:{fontSize:"16px",fontFamily:'"Nunito",sans-serif'},children:e})})},t)}))})]},t)})))}),(0,o.jsx)(l.ZP,{item:!0,xs:12,md:3,children:(0,o.jsxs)(n.Z,{sx:{position:"relative",marginTop:"20px",backgroundColor:"#d1d1d1",borderRadius:"22px",padding:"10px 30px 30px 30px",minHeight:"200px"},children:[(0,o.jsx)(n.Z,{sx:{textAlign:"center",paddingBottom:"10px","& .wordTxt":{fontSize:"40px",fontWeight:"900",fontFamily:'"Nunito",sans-serif',textTransform:"capitalize",color:"orange"}},children:(0,o.jsx)("p",{className:"wordTxt",children:"Rhymes"})}),h.length&&""===(null===h||void 0===h||null===(t=h[0])||void 0===t?void 0:t.rhymes)?null:(0,o.jsx)(n.Z,{sx:{"& .theWord":{fontWeight:500,fontFamily:'"Nunito",sans-serif',width:"100%",fontSize:"16px",padding:"5px 7px 5px 11px",marginBottom:"10px",transition:".3s ease",cursor:"pointer",borderRadius:"75px",backgroundColor:"rgba(255,255,255,1)",color:"black",display:"flex",alignItems:"center","&:hover":{backgroundColor:"rgba(180,180,180,1)"}}},children:null===(i=h[0])||void 0===i||null===(x=i.rhymes)||void 0===x?void 0:x.map((function(e,t){return(0,o.jsxs)("p",{onClick:function(){g.toLowerCase()!=e.toLowerCase()&&(v(!1),setTimeout((function(){w.push("".concat(e))}),1e3))},className:"theWord",children:[(0,o.jsx)(p.Z,{sx:{fontSize:"16px",marginRight:"10px"}}),e]},t)}))})]})})]})]}):(0,o.jsx)(n.Z,{sx:{fontSize:"2rem",fontWeight:"bold",color:"red",textAlign:"center",fontFamily:'"Nunito",sans-serif'},children:"No word details found for ".concat(g,"!")})})]})}),(0,o.jsx)(u.x7,{toastOptions:{style:{fontFamily:'"Nunito",sans-serif'}},position:"top-right"})]})},h=i(9008),g=i.n(h);var y=!0,b=function(e){var t=e.wordData,i=e.slug,r=e.loading;return console.log(t),(0,o.jsxs)(o.Fragment,{children:[(0,o.jsxs)(g(),{children:[(0,o.jsx)("title",{children:"Create Next App"}),(0,o.jsx)("meta",{name:"viewport",content:"width=device-width, initial-scale=1"}),(0,o.jsx)("link",{rel:"icon",href:"/favicon.ico"})]}),(0,o.jsx)("main",{children:(0,o.jsx)(x,{wordApiData:t,slug:i,loading:r})})]})}},6501:function(e,t,i){"use strict";i.d(t,{x7:function(){return ie}});var o=i(7294);let r={data:""},n=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||r,a=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,s=/\/\*[^]*?\*\/|  +/g,l=/\n+/g,d=(e,t)=>{let i="",o="",r="";for(let n in e){let a=e[n];"@"==n[0]?"i"==n[1]?i=n+" "+a+";":o+="f"==n[1]?d(a,n):n+"{"+d(a,"k"==n[1]?"":t)+"}":"object"==typeof a?o+=d(a,t?t.replace(/([^,])+/g,(e=>n.replace(/(^:.*)|([^,])+/g,(t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)))):n):null!=a&&(n=/^--/.test(n)?n:n.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=d.p?d.p(n,a):n+":"+a+";")}return i+(t&&r?t+"{"+r+"}":r)+o},c={},p=e=>{if("object"==typeof e){let t="";for(let i in e)t+=i+p(e[i]);return t}return e},u=(e,t,i,o,r)=>{let n=p(e),u=c[n]||(c[n]=(e=>{let t=0,i=11;for(;t<e.length;)i=101*i+e.charCodeAt(t++)>>>0;return"go"+i})(n));if(!c[u]){let t=n!==e?e:(e=>{let t,i,o=[{}];for(;t=a.exec(e.replace(s,""));)t[4]?o.shift():t[3]?(i=t[3].replace(l," ").trim(),o.unshift(o[0][i]=o[0][i]||{})):o[0][t[1]]=t[2].replace(l," ").trim();return o[0]})(e);c[u]=d(r?{["@keyframes "+u]:t}:t,i?"":"."+u)}let f=i&&c.g?c.g:null;return i&&(c.g=c[u]),((e,t,i,o)=>{o?t.data=t.data.replace(o,e):-1===t.data.indexOf(e)&&(t.data=i?e+t.data:t.data+e)})(c[u],t,o,f),u},f=(e,t,i)=>e.reduce(((e,o,r)=>{let n=t[r];if(n&&n.call){let e=n(i),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;n=t?"."+t:e&&"object"==typeof e?e.props?"":d(e,""):!1===e?"":e}return e+o+(null==n?"":n)}),"");function m(e){let t=this||{},i=e.call?e(t.p):e;return u(i.unshift?i.raw?f(i,[].slice.call(arguments,1),t.p):i.reduce(((e,i)=>Object.assign(e,i&&i.call?i(t.p):i)),{}):i,n(t.target),t.g,t.o,t.k)}m.bind({g:1});let x,h,g,y=m.bind({k:1});function b(e,t){let i=this||{};return function(){let o=arguments;function r(n,a){let s=Object.assign({},n),l=s.className||r.className;i.p=Object.assign({theme:h&&h()},s),i.o=/ *go\d+/.test(l),s.className=m.apply(i,o)+(l?" "+l:""),t&&(s.ref=a);let d=e;return e[0]&&(d=s.as||e,delete s.as),g&&d[0]&&g(s),x(d,s)}return t?t(r):r}}var v=(e,t)=>(e=>"function"==typeof e)(e)?e(t):e,w=(()=>{let e=0;return()=>(++e).toString()})(),j=(()=>{let e;return()=>{if(void 0===e&&typeof window<"u"){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),k=new Map,E=e=>{if(k.has(e))return;let t=setTimeout((()=>{k.delete(e),z({type:4,toastId:e})}),1e3);k.set(e,t)},N=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return t.toast.id&&(e=>{let t=k.get(e);t&&clearTimeout(t)})(t.toast.id),{...e,toasts:e.toasts.map((e=>e.id===t.toast.id?{...e,...t.toast}:e))};case 2:let{toast:i}=t;return e.toasts.find((e=>e.id===i.id))?N(e,{type:1,toast:i}):N(e,{type:0,toast:i});case 3:let{toastId:o}=t;return o?E(o):e.toasts.forEach((e=>{E(e.id)})),{...e,toasts:e.toasts.map((e=>e.id===o||void 0===o?{...e,visible:!1}:e))};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter((e=>e.id!==t.toastId))};case 5:return{...e,pausedAt:t.time};case 6:let r=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map((e=>({...e,pauseDuration:e.pauseDuration+r})))}}},_=[],C={toasts:[],pausedAt:void 0},z=e=>{C=N(C,e),_.forEach((e=>{e(C)}))},T={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},Z=e=>(t,i)=>{let o=((e,t="blank",i)=>({createdAt:Date.now(),visible:!0,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...i,id:(null==i?void 0:i.id)||w()}))(t,e,i);return z({type:2,toast:o}),o.id},S=(e,t)=>Z("blank")(e,t);S.error=Z("error"),S.success=Z("success"),S.loading=Z("loading"),S.custom=Z("custom"),S.dismiss=e=>{z({type:3,toastId:e})},S.remove=e=>z({type:4,toastId:e}),S.promise=(e,t,i)=>{let o=S.loading(t.loading,{...i,...null==i?void 0:i.loading});return e.then((e=>(S.success(v(t.success,e),{id:o,...i,...null==i?void 0:i.success}),e))).catch((e=>{S.error(v(t.error,e),{id:o,...i,...null==i?void 0:i.error})})),e};var $=(e,t)=>{z({type:1,toast:{id:e,height:t}})},P=()=>{z({type:5,time:Date.now()})},F=e=>{let{toasts:t,pausedAt:i}=((e={})=>{let[t,i]=(0,o.useState)(C);(0,o.useEffect)((()=>(_.push(i),()=>{let e=_.indexOf(i);e>-1&&_.splice(e,1)})),[t]);let r=t.toasts.map((t=>{var i,o;return{...e,...e[t.type],...t,duration:t.duration||(null==(i=e[t.type])?void 0:i.duration)||(null==e?void 0:e.duration)||T[t.type],style:{...e.style,...null==(o=e[t.type])?void 0:o.style,...t.style}}}));return{...t,toasts:r}})(e);(0,o.useEffect)((()=>{if(i)return;let e=Date.now(),o=t.map((t=>{if(t.duration===1/0)return;let i=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(!(i<0))return setTimeout((()=>S.dismiss(t.id)),i);t.visible&&S.dismiss(t.id)}));return()=>{o.forEach((e=>e&&clearTimeout(e)))}}),[t,i]);let r=(0,o.useCallback)((()=>{i&&z({type:6,time:Date.now()})}),[i]),n=(0,o.useCallback)(((e,i)=>{let{reverseOrder:o=!1,gutter:r=8,defaultPosition:n}=i||{},a=t.filter((t=>(t.position||n)===(e.position||n)&&t.height)),s=a.findIndex((t=>t.id===e.id)),l=a.filter(((e,t)=>t<s&&e.visible)).length;return a.filter((e=>e.visible)).slice(...o?[l+1]:[0,l]).reduce(((e,t)=>e+(t.height||0)+r),0)}),[t]);return{toasts:t,handlers:{updateHeight:$,startPause:P,endPause:r,calculateOffset:n}}},O=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,D=y`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,A=y`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,L=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${O} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${D} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${A} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,W=y`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,I=b("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${W} 1s linear infinite;
`,R=y`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,H=y`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,B=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${R} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${H} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,M=b("div")`
  position: absolute;
`,q=b("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,U=y`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,X=b("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${U} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,Y=({toast:e})=>{let{icon:t,type:i,iconTheme:r}=e;return void 0!==t?"string"==typeof t?o.createElement(X,null,t):t:"blank"===i?null:o.createElement(q,null,o.createElement(I,{...r}),"loading"!==i&&o.createElement(M,null,"error"===i?o.createElement(L,{...r}):o.createElement(B,{...r})))},G=e=>`\n0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}\n100% {transform: translate3d(0,0,0) scale(1); opacity:1;}\n`,J=e=>`\n0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}\n100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}\n`,K=b("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,Q=b("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,V=o.memo((({toast:e,position:t,style:i,children:r})=>{let n=e.height?((e,t)=>{let i=e.includes("top")?1:-1,[o,r]=j()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[G(i),J(i)];return{animation:t?`${y(o)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${y(r)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||t||"top-center",e.visible):{opacity:0},a=o.createElement(Y,{toast:e}),s=o.createElement(Q,{...e.ariaProps},v(e.message,e));return o.createElement(K,{className:e.className,style:{...n,...i,...e.style}},"function"==typeof r?r({icon:a,message:s}):o.createElement(o.Fragment,null,a,s))}));!function(e,t,i,o){d.p=t,x=e,h=i,g=o}(o.createElement);var ee=({id:e,className:t,style:i,onHeightUpdate:r,children:n})=>{let a=o.useCallback((t=>{if(t){let i=()=>{let i=t.getBoundingClientRect().height;r(e,i)};i(),new MutationObserver(i).observe(t,{subtree:!0,childList:!0,characterData:!0})}}),[e,r]);return o.createElement("div",{ref:a,className:t,style:i},n)},te=m`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,ie=({reverseOrder:e,position:t="top-center",toastOptions:i,gutter:r,children:n,containerStyle:a,containerClassName:s})=>{let{toasts:l,handlers:d}=F(i);return o.createElement("div",{style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...a},className:s,onMouseEnter:d.startPause,onMouseLeave:d.endPause},l.map((i=>{let a=i.position||t,s=((e,t)=>{let i=e.includes("top"),o=i?{top:0}:{bottom:0},r=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:j()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(i?1:-1)}px)`,...o,...r}})(a,d.calculateOffset(i,{reverseOrder:e,gutter:r,defaultPosition:t}));return o.createElement(ee,{id:i.id,key:i.id,onHeightUpdate:d.updateHeight,className:i.visible?te:"",style:s},"custom"===i.type?v(i.message,i):n?n(i):o.createElement(V,{toast:i,position:a}))})))}}},function(e){e.O(0,[164,441,774,888,179],(function(){return t=6786,e(e.s=t);var t}));var t=e.O();_N_E=t}]);